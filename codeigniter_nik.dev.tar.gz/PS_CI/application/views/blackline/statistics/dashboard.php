  <script src="<?=base_url()?>assets/blackline/js/raphael-min.js"></script>
  <script src="<?=base_url()?>assets/blackline/js/morris-min.js"></script>
  <script src="<?=base_url()?>assets/blackline/js/hs/js/highcharts.js"></script>
<script src="<?=base_url()?>assets/blackline/js/hs/js/modules/exporting.js"></script>
<!--<script type="text/javascript" src="<?=base_url()?>assets/blackline/js/chart.js"></script>-->
  <script type="text/javascript">
  /*$(document).ready(function(){
    $("#test").load("https://proffsecurity.no/backend/ajax/getGraph", function(data){
      $(this).html(data);
    });
  });*/


	$(document).ready(function(){
				$('#daterange').daterangepicker({
                        ranges: {
                           'Idag': [new Date(), new Date()],
                           'Igår': [moment().subtract('days', 1), moment().subtract('days', 1)],
                           'Siste 7 dager': [moment().subtract('days', 6), new Date()],
                           'Siste 30 dager': [moment().subtract('days', 29), new Date()],
                           'Denne måned': [moment().startOf('month'), moment().endOf('month')],
                           'Siste måned': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                        },
                        opens: 'left',
                        format: 'DD/MM/YYYY',
                        separator: ' - ',
                        startDate: moment().subtract('days', 29),
                        endDate: new Date(),
                        minDate: '01/01/2012',
                        maxDate: '12/31/2030',
                        locale: {
                            applyLabel: 'Ok',
                            fromLabel: 'Fra',
                            toLabel: 'Til',
                            customRangeLabel: 'Egendefinert',
                            daysOfWeek: ['Sø', 'Ma', 'Ti', 'On', 'To', 'Fr','Lø'],
                            monthNames: ['Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'],
                            firstDay: 1
                        },
                        showWeekNumbers: true,
                        buttonClasses: ['btn-danger'],
                        dateLimit: false
                     },
                     function(start, end) {
                        $('#daterange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                     }
				);

				$('.dropdowns').change(function(){
					if($('#graphone_object_hidden').val()!=$('#graphone_object').val()){
						$('#graphone_company').val('All Company');
					}
					if($('#graphtwo_object_hidden').val()!=$('#graphtwo_object').val()){
						$('#graphtwo_company').val('All Company');
					}
					if($('#tableone_object_hidden').val()!=$('#tableone_object').val()){
						$('#tableone_company').val('All Company');
					}
					$('#graphone_object_hidden').val($('#graphone_object').val());
					$('#graphone_company_hidden').val($('#graphone_company').val());
					$('#graphone_month_hidden').val($('#graphone_month').val());
					$('#graphtwo_object_hidden').val($('#graphtwo_object').val());
					$('#graphtwo_company_hidden').val($('#graphtwo_company').val());
					$('#graphtwo_year_hidden').val($('#graphtwo_year').val());
					$('#tableone_object_hidden').val($('#tableone_object').val());
					$('#tableone_company_hidden').val($('#tableone_company').val());
					$('#tableone_date_hidden').val($('#daterange').val());
					$('#submit_form').click();
				});

				$('#pie').change(function(){
					$('#pie_hidden').val($('#pie').val());
					$('#submit_form').click();
				});

				$('#pie_date').change(function(){
					$('#pie_date_hidden').val($('#pie_date').val());
					$('#submit_form').click();
				});

				$('#daterange').blur(function(){
					$('#tableone_date_hidden').val($('#daterange').val());
					$('#submit_form').click();
				});




});

  $(function () {
        $('#barChart').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Antall Hendelser'
            },
            subtitle: {
                text: 'test<?php //echo $subtitle_of_bar_chart;?>'
            },
            credits: {
            enabled: false
            },
			xAxis: {
	categories: [
						'Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'
				]
			},
            yAxis: {
            title: {
              text: 'Antall Hendelser',
              align: 'middle'
            },
                min: 0,



            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [<?php echo $bar_chart;?>]
        });


    });


<?php if(isset($barchart2)){ ?>
			$(document).ready(function(){
			    $('#barChart2').highcharts({
					chart: {
						type: 'column',
						events: {
							redraw: function() {
								//alert ('The chart was just redrawn');
							}
						}
					},
					title: {
						text: 'Antall Hendelser pr.oppgavekode'
					},
					subtitle: {
						text: '<?php echo $barchart2_subtitle; ?> statistikk - 2013'
					},
					credits: {
						enabled: false
					},
					xAxis: {
						categories: [
							'Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'
						]
					},
					yAxis: {
						title: {
							text: 'Antall Hendelser pr.oppgavekode',
							align: 'middle'
						},
						min: 0,



					},
					tooltip: {
						headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
						pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
							'<td style="padding:0"><b>{point.y}</b></td></tr>',
						footerFormat: '</table>',
						shared: true,
						useHTML: true
					},
					plotOptions: {
						column: {
							pointPadding: 0.2,
							borderWidth: 0
						}
					},
					series:
					[
						<?php echo $barchart2; ?>
					]
				});


	   $('#pieChart').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text : 'Tilkalling'
            },
            subtitle: {
                text: '<?php //echo $pie_chart_subtitle;?>'
            },
            tooltip: {
              pointFormat: '{series.name}: <b>{point.percentage}%</b>',
              formatter: function() {
                            return '<b>'+ this.point.name +'</b>: '+ Math.round(this.percentage) +' %';
                  }
            },
            credits: {
            enabled: false
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function() {
                            return '<b>'+ this.point.name +'</b>: '+ Math.round(this.percentage) +' %';
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Statistics',
                data:  [<?php echo $piegraph; ?>]
            }]
        });


			});
<?php } ?>

  </script>


<div class="main">

  <div class="span6">
    <div class="span6" style="width: 100% !important; float:left;">
      <div id="baseDateControl" style="float:left; width: 100% !important; ">
          <div class="well">
            <div style="float:left">
                <form class="form-horizontal">
                 <fieldset>
                  <div class="control-group">
                    <!--<label class="control-label" for="reservation">Filter - Objekt:</label>-->
                    <div class="controls" style="float: left; margin-left: 10px !important;">
                      <div class="input-prepend">

						<select id="graphone_object" class="dropdowns">
							<?php if($this->user){ ?><option>Velg Objekt</option> <?php } ?>
							<?php foreach($dropdowns as $dd){ ?>
								<option <?php if(isset($_POST['graphone_object'])){ if($_POST['graphone_object']==$dd->object){ ?>selected<?php }} ?>><?php echo $dd->object; ?></option>
							<?php } ?>
						</select>

                      </div>
                    </div>
					<?php if(isset($graphone_companies)){ ?>
					<div class="controls" style="float: left; margin-left: 20px !important;">
                      <div class="input-prepend">

						<select id="graphone_company" class="dropdowns">
							<?php if($this->user){ ?><option value="All Company">Velg Company</option> <?php } ?>
							<?php foreach($graphone_companies as $dd){ ?>
								<option <?php if(isset($_POST['graphone_company'])){ if($_POST['graphone_company']==$dd->company){ ?>selected<?php }} ?>><?php echo $dd->company; ?></option>
							<?php } ?>
						</select>

                      </div>
                    </div>
					<?php } ?>
                  </div>

                 </fieldset>
                </div>
					<div class="controls" style="float: right; margin-right: 10px !important;">
                      <div class="input-prepend">

						<select id="graphone_month" class="dropdowns">
								<option>All</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==1)? 'selected' : ''; } ?> value="1">Januar</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==2)? 'selected' : ''; } ?> value="2">Februar</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==3)? 'selected' : ''; } ?> value="3">Mars</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==4)? 'selected' : ''; } ?> value="4">April</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==5)? 'selected' : ''; } ?> value="5">Mai</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==6)? 'selected' : ''; } ?> value="6">Juni</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==7)? 'selected' : ''; } ?> value="7">Juli</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==8)? 'selected' : ''; } ?> value="8">August</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==9)? 'selected' : ''; } ?> value="9">September</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==10)? 'selected' : ''; } ?> value="10">Oktober</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==11)? 'selected' : ''; } ?> value="11">November</option>
								<option <?php if(isset($_POST['graphone_month'])){ echo ($_POST['graphone_month']==12)? 'selected' : ''; } ?> value="12">Desember</option>
						</select>

                      </div>
                    </div>
                </form>
              </div>
            </div>

    <?php if(isset($barchart2)){ ?>
      <div id="barChart2" style="width= 100%; margin: 0 auto; height: 500px;">
	  </div>
    <?php } ?>
  </div>
</div>

  <div class="span6">
    <div>
      <div class="well">
              <div style="float:left">
                <form class="form-horizontal">
                 <fieldset>
                  <div class="control-group">
                    <label class="control-label" for="reservation"></label>
                    <div class="controls" style="margin-left: 0 !important;">
                      <div class="input-prepend">
                       <?php //print_r($object_name);?>
                        <select class="dropdowns" id="graphtwo_object">
							<?php if($this->user){ ?><option>Velg Objekt</option> <?php } ?>
							<?php foreach($dropdowns as $dd){ ?>
								<option <?php if(isset($_POST['graphtwo_object'])){ if($_POST['graphtwo_object']==$dd->object){ ?>selected<?php }} ?>><?php echo $dd->object; ?></option>
							<?php } ?>
                        </select>
                      </div>
                    </div>
					</div>


					<?php if(isset($graphtwo_companies)){ ?>
					<div class="controls" style="float: left; margin-left: 20px !important;">
                      <div class="input-prepend">

						<select id="graphtwo_company" class="dropdowns">
							<?php if($this->user){ ?><option value="All Company">Velg Sted</option> <?php } ?>
							<?php foreach($graphtwo_companies as $dd){ ?>
								<option <?php if(isset($_POST['graphtwo_company'])){ if($_POST['graphtwo_company']==$dd->company){ ?>selected<?php }} ?>><?php echo $dd->company; ?></option>
							<?php } ?>
						</select>

                      </div>
                    </div>
					<?php } ?>
                  </div>
                 </fieldset>
				 <div class="controls" style="float: right; margin-right: 10px !important;">
                      <div class="input-prepend">

						<select id="graphtwo_year" class="dropdowns">
								<?php for($x=$theyearmax;$x>=$theyearmin;$x--){ ?>
								<option <?php if(isset($_POST['graphtwo_year'])){ echo ($_POST['graphtwo_year']==$x)? 'selected' : ''; } ?>><?php echo $x; ?></option>
								<?php } ?>
							</select>

                      </div>
                    </div>
                </form>
              </div>
      </div>
		  <div id="barChart" style="width= 100% !important; height: 500px;"></div>
	  </div>
  </div>

  <div class="span6" style="margin-left: 0px;">    <!-- Last modified by joel -->
    <div class="span6" style="width: 100% !important; float:left;">
      <div id="baseDateControl" style="float:left; width: 100% !important; ">
        <div class="well">
          <div style="float:right">
            <form class="form-horizontal">
              <fieldset>
                <div class="control-group">
                  <!--<label class="control-label" for="reservation">Velg Periode:</label>-->
                    <div class="controls" style="margin-left: 0 !important;">
                      <div class="input-prepend">
                       <span class="add-on"><i class="icon-calendar"></i></span><input type="text" id="daterange" style="width: 85% !important;"  <?php if(isset($_POST['tableone_date'])){ ?>value="<?php echo $_POST['tableone_date']; ?>"<?php }else{ ?>value="<?php echo date("d/m/Y");?> - <?php echo date("d/m/Y");?>"<?php } ?> />
                      </div>
                    </div>
                </div>
              </fieldset>
            </form>
          </div>

          <div style="float:left; padding-left: 20px;">
            <form class="form-horizontal">
              <fieldset>
                <div class="control-group">
                    <div class="controls" style="margin-left: 0 !important;">
                      <div class="input-prepend">
                        <div id="dropdown_container">
                          <div id="dropdown_container">
                            <select id="tableone_object" class="dropdowns">
							<?php if($this->user){ ?><option>Velg Objekt</option> <?php } ?>
							<?php foreach($dropdowns as $dd){ ?>
								<option <?php if(isset($_POST['tableone_object'])){ echo ($_POST['tableone_object']==$dd->object)? 'selected' : ''; } ?>><?php echo $dd->object; ?></option>
							<?php } ?>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
          </div>
		<div style="float:left; padding-left: 20px;">
            <form class="form-horizontal">
              <fieldset>
                <div class="control-group">
                    <div class="controls" style="margin-left: 0 !important;">
                      <div class="input-prepend">
                        <div id="dropdown_container">
                          <div id="dropdown_container">
                            <select id="tableone_company" class="dropdowns">
							<?php if($this->user){ ?><option>Velg Sted</option> <?php } ?>
							<?php foreach($tbl_dd as $dd){ ?>
								<option <?php if(isset($_POST['tableone_company'])){ echo ($_POST['tableone_company']==$dd->company)? 'selected' : ''; } ?>><?php echo $dd->company; ?></option>
							<?php } ?>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
          </div>
        </div>
      </div>
    </div>

    <div class="table_head"><h6><i class="icon-list-alt"></i>Antall personer pr.oppgavekode</h6></div>
      <table id="stats_table" width="100%">
        <thead>
          <th width='1%'>Oppgavekode</th>
          <th width='1%'>Antall Personer</th>
        </thead>
        <?php $total = 0; ?>
          <tbody>
            <?php foreach($tblone as $taskcode){ ?>
            <tr>
                <td><?php echo $taskcode->taskcode; ?></td>
                <td><?php echo $taskcode->tsum; ?></td>
              <?php $total += $taskcode->tsum; ?>
            </tr>
            <?php } ?>
          </tbody>
          <tfoot>
            <tr>
            <td><strong>Totalt</strong></td>
            <td id="total_count"><?php echo $total; ?></td>
            </tr>
          </tfoot>
      </table>
    </div>

  <div class="span6" style="float:right">
    <div class="span6" style="width: 100% !important; float:left;">
        <div id="baseDateControl" style="float:left; width: 100% !important; ">
          <div class="well">
            <div style="float:left">
              <form class="form-horizontal">
                <fieldset>
                  <div class="control-group">
                    <div class="controls" style="margin-left: 0 !important;">
                      <div class="input-prepend">
                       <select id="pie">
							<?php if($this->user){ ?><option>Velg Objekt</option> <?php } ?>
							<?php foreach($dropdowns as $dd){ ?>
								<option <?php if(isset($_POST['pie'])){ if($_POST['pie']==$dd->object){ echo 'selected';  } } ?>><?php echo $dd->object; ?></option>
							<?php } ?>
                        </select>
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
              </div>
            <div style="float:right">
              <form class="form-horizontal">
                <fieldset>
                  <div class="control-group">
                    <div class="controls">
                      <div class="input-prepend">
                       <select id="pie_date">
							<option>All</option>
							<?php for($x=$theyearmax;$x>=$theyearmin;$x--){ ?>
								<?php for($y=$themonthmax;$y>=$themonthmin;$y--){ ?>
									<?php $thepie = explode(' ',$this->input->post('pie_date')); ?>
									<?php if($y<1){ $y = 12; } ?>
									<?php if($y==1){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="1 <?php echo $x; ?>"><?php echo "January ".$x; ?></option>
									<?php }else if($y==2){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="2 <?php echo $x; ?>"><?php echo "February ".$x; ?></option>
									<?php }else if($y==3){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="3 <?php echo $x; ?>"><?php echo "March ".$x; ?></option>
									<?php }else if($y==4){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="4 <?php echo $x; ?>"><?php echo "April ".$x; ?></option>
									<?php }else if($y==5){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="5 <?php echo $x; ?>"><?php echo "May ".$x; ?></option>
									<?php }else if($y==6){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="6 <?php echo $x; ?>"><?php echo "June ".$x; ?></option>
									<?php }else if($y==7){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="7 <?php echo $x; ?>"><?php echo "July ".$x; ?></option>
									<?php }else if($y==8){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="8 <?php echo $x; ?>"><?php echo "August ".$x; ?></option>
									<?php }else if($y==9){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="9 <?php echo $x; ?>"><?php echo "September ".$x; ?></option>
									<?php }else if($y==10){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="10 <?php echo $x; ?>"><?php echo "October ".$x; ?></option>
									<?php }else if($y==11){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="11 <?php echo $x; ?>"><?php echo "November ".$x; ?></option>
									<?php }else if($y==12){ ?>
											<option <?php if($y==$thepie[0] && $x==$thepie[1]){ echo 'selected'; } ?> value="12 <?php echo $x; ?>"><?php echo "December ".$x; ?></option>
									<?php } ?>
								<?php } ?>
							<?php } ?>
                        </select>
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
              </div>
          </div>
            <div id="pieChart" style="width= 100% !important; height: 500px;"></div>
        </div>

    </div>
    <br clear="all">
  </div>
</div>
      <?php
      /*$line1 = "";
      for ($i = 01; $i <= 12; $i++) {

        $num = "0";
        foreach ($stats as $value):
        $act_month = explode("-", $value->paid_date);
        if($act_month[1] == $i){
          $num = $value->summary;
        }
        endforeach;
          $i = sprintf("%02.2d", $i);
          $line1 .= "{m: '".$year."-".$i."', a: ".$num."}";
          if($i != "12"){ $line1 .= ",";}
        } */?>



  <script type="text/javascript">
    $(document).ready(function(){

	  $('#stats_table').dataTable({
			"bPaginate": true ,
			"bFilter": true,
        });


function tick(){
  $('ul.messages li:first').slideUp('slow', function () { $(this).appendTo($('ul.messages')).fadeIn('slow'); });
}
<?php
if(isset($message)){
if(count($message) > 2){ ?>
setInterval(function(){ tick() }, 5000);
<?php }
} ?>
$('ul.eventlist li').click(function(){
  $('ul.eventlist li:first').slideUp('slow', function () { $(this).appendTo($('ul.eventlist')).fadeIn('slow'); });
});



    });

    </script>


      <script type="text/javascript" src="<?=base_url()?>assets/blackline/js/jquery.mousewheel.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/blackline/js/jquery.jscrollpane.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/blackline/js/scroll-startstop.events.jquery.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/blackline/js/scroll-startstop.events.jquery.js"></script>


    <script type="text/javascript">
      $(function() {

        // the element we want to apply the jScrollPane
        var $el         = $('.jp-container').jScrollPane({
          verticalGutter  : -16
        }),

        // the extension functions and options
          extensionPlugin   = {

            extPluginOpts : {
              // speed for the fadeOut animation
              mouseLeaveFadeSpeed : 500,
              // scrollbar fades out after hovertimeout_t milliseconds
              hovertimeout_t    : 1000,
              // if set to false, the scrollbar will be shown on mouseenter and hidden on mouseleave
              // if set to true, the same will happen, but the scrollbar will be also hidden on mouseenter after "hovertimeout_t" ms
              // also, it will be shown when we start to scroll and hidden when stopping
              useTimeout      : false,
              // the extension only applies for devices with width > deviceWidth
              deviceWidth     : 980
            },
            hovertimeout  : null, // timeout to hide the scrollbar
            isScrollbarHover: false,// true if the mouse is over the scrollbar
            elementtimeout  : null, // avoids showing the scrollbar when moving from inside the element to outside, passing over the scrollbar
            isScrolling   : false,// true if scrolling
            addHoverFunc  : function() {

              // run only if the window has a width bigger than deviceWidth
              if( $(window).width() <= this.extPluginOpts.deviceWidth ) return false;

              var instance    = this;

              // functions to show / hide the scrollbar
              $.fn.jspmouseenter  = $.fn.show;
              $.fn.jspmouseleave  = $.fn.fadeOut;

              // hide the jScrollPane vertical bar
              var $vBar     = this.getContentPane().siblings('.jspVerticalBar').hide();

              /*
               * mouseenter / mouseleave events on the main element
               * also scrollstart / scrollstop - @James Padolsey : http://james.padolsey.com/javascript/special-scroll-events-for-jquery/
               */
              $el.bind('mouseenter.jsp',function() {

                // show the scrollbar
                $vBar.stop( true, true ).jspmouseenter();

                if( !instance.extPluginOpts.useTimeout ) return false;

                // hide the scrollbar after hovertimeout_t ms
                clearTimeout( instance.hovertimeout );
                instance.hovertimeout   = setTimeout(function() {
                  // if scrolling at the moment don't hide it
                  if( !instance.isScrolling )
                    $vBar.stop( true, true ).jspmouseleave( instance.extPluginOpts.mouseLeaveFadeSpeed || 0 );
                }, instance.extPluginOpts.hovertimeout_t );


              }).bind('mouseleave.jsp',function() {

                // hide the scrollbar
                if( !instance.extPluginOpts.useTimeout )
                  $vBar.stop( true, true ).jspmouseleave( instance.extPluginOpts.mouseLeaveFadeSpeed || 0 );
                else {
                clearTimeout( instance.elementtimeout );
                if( !instance.isScrolling )
                    $vBar.stop( true, true ).jspmouseleave( instance.extPluginOpts.mouseLeaveFadeSpeed || 0 );
                }

              });

              if( this.extPluginOpts.useTimeout ) {

                $el.bind('scrollstart.jsp', function() {

                  // when scrolling show the scrollbar
                  clearTimeout( instance.hovertimeout );
                  instance.isScrolling  = true;
                  $vBar.stop( true, true ).jspmouseenter();

                }).bind('scrollstop.jsp', function() {

                  // when stop scrolling hide the scrollbar (if not hovering it at the moment)
                  clearTimeout( instance.hovertimeout );
                  instance.isScrolling  = false;
                  instance.hovertimeout   = setTimeout(function() {
                    if( !instance.isScrollbarHover )
                      $vBar.stop( true, true ).jspmouseleave( instance.extPluginOpts.mouseLeaveFadeSpeed || 0 );
                  }, instance.extPluginOpts.hovertimeout_t );

                });

                // wrap the scrollbar
                // we need this to be able to add the mouseenter / mouseleave events to the scrollbar
                var $vBarWrapper  = $('<div/>').css({
                  position  : 'absolute',
                  left    : $vBar.css('left'),
                  top     : $vBar.css('top'),
                  right   : $vBar.css('right'),
                  bottom    : $vBar.css('bottom'),
                  width   : $vBar.width(),
                  height    : $vBar.height()
                }).bind('mouseenter.jsp',function() {

                  clearTimeout( instance.hovertimeout );
                  clearTimeout( instance.elementtimeout );

                  instance.isScrollbarHover = true;

                  // show the scrollbar after 100 ms.
                  // avoids showing the scrollbar when moving from inside the element to outside, passing over the scrollbar
                  instance.elementtimeout = setTimeout(function() {
                    $vBar.stop( true, true ).jspmouseenter();
                  }, 100 );

                }).bind('mouseleave.jsp',function() {

                  // hide the scrollbar after hovertimeout_t
                  clearTimeout( instance.hovertimeout );
                  instance.isScrollbarHover = false;
                  instance.hovertimeout = setTimeout(function() {
                    // if scrolling at the moment don't hide it
                    if( !instance.isScrolling )
                      $vBar.stop( true, true ).jspmouseleave( instance.extPluginOpts.mouseLeaveFadeSpeed || 0 );
                  }, instance.extPluginOpts.hovertimeout_t );

                });

                $vBar.wrap( $vBarWrapper );

              }

            }

          },

          // the jScrollPane instance
          jspapi      = $el.data('jsp');

        // extend the jScollPane by merging
        $.extend( true, jspapi, extensionPlugin );
        jspapi.addHoverFunc();

      });
    </script>

	<form action="<?php base_url(); ?>statistics" method="post">
		<input type="hidden" id="graphone_object_hidden" name="graphone_object" <?php if(isset($_POST['graphone_object'])){ ?>value="<?php echo $_POST['graphone_object']; ?>"<?php }else{ ?>value="Velg Objekt"<?php } ?> />
		<input type="hidden" id="graphone_company_hidden" name="graphone_company" <?php if(isset($_POST['graphone_company'])){ ?>value="<?php echo $_POST['graphone_company']; ?>"<?php }else{ ?>value="All Company"<?php } ?>/>
		<input type="hidden" id="graphone_month_hidden" name="graphone_month" <?php if(isset($_POST['graphone_month'])){ ?>value="<?php echo $_POST['graphone_month']; ?>"<?php }else{ ?>value="All"<?php } ?> />
		<input type="hidden" id="graphtwo_object_hidden" name="graphtwo_object" <?php if(isset($_POST['graphtwo_object'])){ ?>value="<?php echo $_POST['graphtwo_object']; ?>"<?php }else{ ?>value="Velg Objekt"<?php } ?> />
		<input type="hidden" id="graphtwo_company_hidden" name="graphtwo_company" <?php if(isset($_POST['graphtwo_company'])){ ?>value="<?php echo $_POST['graphtwo_company']; ?>"<?php }else{ ?>value="All Company"<?php } ?>/>
		<input type="hidden" id="graphtwo_year_hidden" name="graphtwo_year" <?php if(isset($_POST['graphtwo_year'])){ ?>value="<?php echo $_POST['graphtwo_year']; ?>"<?php }else{ ?>value="<?php echo $theyearmax; ?>"<?php } ?> />
		<input type="hidden" id="tableone_object_hidden" name="tableone_object" <?php if(isset($_POST['tableone_object'])){ ?>value="<?php echo $_POST['tableone_object']; ?>"<?php }else{ ?>value="Velg Objekt"<?php } ?> />
		<input type="hidden" id="tableone_company_hidden" name="tableone_company" <?php if(isset($_POST['tableone_company'])){ ?>value="<?php echo $_POST['tableone_company']; ?>"<?php }else{ ?>value="All Company"<?php } ?>/>
		<input type="hidden" id="tableone_date_hidden" name="tableone_date" <?php if(isset($_POST['tableone_date'])){ ?>value="<?php echo $_POST['tableone_date']; ?>"<?php }else{ ?>value="<?php echo date("d/m/Y");?> - <?php echo date("d/m/Y");?>"<?php } ?>/>
		<input type="hidden" id="pie_hidden" name="pie" <?php if(isset($_POST['pie'])){ ?>value="<?php echo $_POST['pie']; ?>"<?php }else{ ?>value="Velg Objekt"<?php } ?>/>
		<input type="hidden" id="pie_date_hidden" name="pie_date" <?php if(isset($_POST['pie_date'])){ ?>value="<?php echo $_POST['pie_date']; ?>"<?php }else{ ?>value="All"<?php } ?>/>
		<input type="submit" id="submit_form" style="display: none;" />
	</form>