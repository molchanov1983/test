<!DOCTYPE html>

<html>
<head>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>
<body>

<?php

$th='';
$td='';
//create th and tr
foreach ($arr as $keyName => $keyValue) {
    $th .= '<th>' . $keyName . '<th>';
    $td .= '<td>' . $keyValue . '<td>';
}

?>
     <table style="width:500px">
                <tr>
                    <?php echo $th;?>
                </tr>
                <tr>
                      <?php echo $td;?>
                </tr>
    </table>


</body>
</html>
