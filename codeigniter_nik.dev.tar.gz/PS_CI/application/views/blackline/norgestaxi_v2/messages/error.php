<div name="alex_alert_error">
  <div class="alert alert-error">
    <?php echo $message;?>
  </div>
</div>
