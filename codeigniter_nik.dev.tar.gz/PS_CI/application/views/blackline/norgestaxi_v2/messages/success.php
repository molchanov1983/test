<div name="alex_alert_success">
  <div class="alert alert-success">
    <?php echo $message; ?>
  </div>
</div>
