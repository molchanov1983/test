


<!-- Modal -->
<div class="modal fade" id="editReportModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
          <p>
              <!--here i need to load form-->
              <?php echo $this->load->view('blackline/norgestaxi_v2/form/create_form');?>
          </p>
      </div>
      <div class="modal-footer">
        <div class="modal-footer">
            <a name="confirn_yes" data-url="<?php echo base_url('norgestaxi_v2/update/');?>" href="<?php echo base_url('norgestaxi_v2/update/');?>" class="btn danger">
                <?php echo $this->lang->line('application_Yes') ?>
            </a>
            <a name="confirn_no" href="#" data-dismiss="modal" class="btn default">
                    <?php echo $this->lang->line('application_No') ?>
            </a>
        </div>

      </div>
    </div>
  </div>
</div>