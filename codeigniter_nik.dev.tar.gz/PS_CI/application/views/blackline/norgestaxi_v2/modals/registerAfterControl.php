<!-- Modal -->
<div class="modal fade" id="registerAfterControlModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
          <p>
              <!--here i need to load form-->
              <?php echo $this->load->view('blackline/norgestaxi_v2/form/register_after_control_form');?>
          </p>
      </div>
      <div class="modal-footer">


      </div>
    </div>
  </div>
</div>

<!--this is for js-->
<script>
    var wrongdateFormat = '<?php echo $this->lang->line('messages_not_right_date_format') ?>';
    var wrongPhonenumberFormat = '<?php echo $this->lang->line('messages_not_right_phonenumber_format') ?>';
</script>


