<div id="main">
	<div class="visible-phone"><br/></div>
        
		<?php 
			if($this->user){ ?>
    	<div id="options">
    		<a class="btn" id="service" href="<?php echo base_url('norgestaxi/create'); ?>"><i class="icon-plus-sign"></i> Nytt Kontrollskjema</a>
    	</div>
		<?php 
			}
		?>

    <br clear="all">

    <div class="span12" style="margin-left: 0px;">
    <div class="span12" style="width: 100% !important; float:left;">
        <div id="baseDateControl">
          <div class="well">
            <div style="float:left"> 
              <form class="form-horizontal">
                <fieldset>
                  <div class="control-group">
                    <label class="control-label" for="reservation">Tidsperiode:</label>
                    <div class="controls">
                      <div class="input-prepend">
						<input type="text" id="reports_daterange" value="<?php echo date("d/m/Y");?> - <?php echo date("d/m/Y");?>" />
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
              </div>
          </div>	
    		<div class="table_head"><h6><i class="icon-list-alt"></i>Alle Kontroller</h6></div>
    			<table width='100%' id="reports_table" border='0' align='center' cellpadding='0' cellspacing='0' rel="#">
        			<thead>
        				<tr>
            				<th width='1%'>ID</th>
            				<th width='1%'>Dato & Tid</th>
            				<th width='1%'>Løyve nr</th>
            				<th width='1%'>Sjåfør nr</th>
            				<th width='1%'>Bil reg</th>
            				<th width='1%'>Kontroll Sted</th>
							      <th width="1%">Status</th>
            				<th width="1%">Tjenestenr</th>
            				<th width='2%'>Valg</th>
        				</tr>
        			</thead>
        		<tbody id="report_tbl">
					<?php foreach($nt_reports as $reports){ ?>
						<tr>
                    		<td><?php echo $reports->main_id; ?></td>
                        <?php if(@$this->client) { ?>
                    		<td><?php echo date("d/m/Y", strtotime($reports->datetime)); ?></td>
                        <?php } ?>
                        <?php if(@$this->user) { ?>
                        <td><?php echo date("d/m/Y H:i", strtotime($reports->datetime)); ?></td>
                        <?php } ?>
                    		<td><?php echo $reports->car_grants; ?></td>
                    		<td><?php echo $reports->driver_number; ?></td>
                    		<td><?php echo $reports->plate_chars; ?></td>
                    		<td><?php echo $reports->location_name; ?></td>
                    		<td><?php echo (strtolower($reports->report_status) == "approved")?'<span class="label label-success">Godkjent</span>':'<span class="label label-important">Ikke Godkjent</span>'; ?></td>
                    		<td><?php echo $reports->employee_id; ?></td>
                    	<td class="option btn-group">						
							<a data-target="#myModal" amdata="report" role="button" class="btn btn-mini" data-toggle="modal"  href="<?php echo base_url('norgestaxi/edit/car/'.$reports->main_id); ?>">Rediger Bilkontroll</a>
							<a data-target="#myModal" role="button" class="btn btn-mini" data-toggle="modal" href="<?php echo base_url('norgestaxi/edit/driver/'.$reports->main_id); ?>">Rediger Sjåførkontroll</a>
							<a data-target="#myModal" role="button" class="btn btn-mini" data-toggle="modal" href="<?php echo base_url('norgestaxi/edit/report/'.$reports->main_id); ?>">Rediger</a>
							<a data-target="#myModal" role="button" class="btn btn-mini" data-toggle="modal" href="<?php echo base_url('norgestaxi/view_report/'.$reports->main_id); ?>">Se Kontroll</a>
                    	</td>
						</tr>
					<?php } ?>
     			</tbody>   
    			</table>
    	</div>
	</div>
	</div>

    <br clear="all">
    <br clear="all">
    <?php if(@$this->user) { ?>
    <div class="span6" style="margin-left: 0px;">
    <div class="span6" style="width: 100% !important; float:left;">
        <div id="baseDateControl" style="float:left; width: 100% !important; ">
          <div class="well">
            <div style="float:left"> 
              <form class="form-horizontal">
                <fieldset>
                  <div class="control-group">
                    <label class="control-label" for="reservation">Tidsperiode:</label>
                    <div class="controls">
                      <div class="input-prepend">
						<input type="text" class="daterange" id="cars_daterange" value="<?php echo date("d/m/Y");?> - <?php echo date("d/m/Y");?>" />
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
              </div>
          </div>
            <div class="table_head"><h6><i class="icon-list-alt"></i>Ikke Godkjente - Biler</h6></div>
    			<table width="100%" id="cars_table">
        			<thead>
        			<tr>
            		<th>ID</th>
            		<th>Sist Endret</th>
            		<th>Løyve nr</th>
            		<th>Bil regnr</th>
					      <th>Status</th>
            		<th>Tjenestenr</th>
            		<th>Valg</th>
        			</tr>
        			</thead>
        		<tbody id="cars_tbl">
				<?php foreach($nt_cars as $cars){ ?>
					<?php if($cars->nt_car_status=='not approved'){ ?>
				<tr>
                    <td><?php echo $cars->main_id; ?></td>
                    <td><?php echo date("d/m/Y H:i", strtotime($cars->last_modified)); ?></td>
                    <td><?php echo $cars->car_grants; ?></td>
                    <td><?php echo $cars->plate_chars; ?></td>
                    <!--
                    <td><?php echo $cars->nt_car_status; ?></td>
                    -->
                    <td><span class="label label-important">Ikke Godkjent</span></td>
                    <td><?php echo $cars->employee_id; ?></td>
                    <td class="option btn-group">
							<a data-target="#myModal"  role="button" class="btn btn-mini" data-toggle="modal" href="<?php echo base_url('norgestaxi/edit/car/'.$cars->main_id); ?>">Rediger</a>
					</td>
				</tr>
				<?php } ?>
				<?php } ?>
     			</tbody>   
    			</table>
    	</div>
    </div>
    </div>


    <!-- <br clear="all"> -->



    <div class="span6" style="float:right">
    <div class="span6" style="width: 100% !important; float:left;">
        <div id="baseDateControl" style="float:left; width: 100% !important; ">
          <div class="well">
            <div style="float:left"> 
              <form class="form-horizontal">
                <fieldset>
                  <div class="control-group">
                    <label class="control-label" for="reservation">Tidsperiode:</label>
                    <div class="controls">
                      <div class="input-prepend">
						<input type="text" class="daterange" id="drivers_daterange" value="<?php echo date("d/m/Y");?> - <?php echo date("d/m/Y");?>" />
                      </div>
                    </div>
                  </div>
                </fieldset>
              </form>
              </div>
          </div>
            <div class="table_head"><h6><i class="icon-list-alt"></i>Ikke Godkjente Sjåfører</h6></div>
    	<table width="100%" id="drivers_table">
        	<thead>
        		<tr>
            	<th>ID</th>
            	<th>Sist Endret</th>
            	<th>Sjåfør nr</th>
				      <th>Status</th>
            	<th>Tjenestenr</th>
            	<th>Valg</th>
        	</tr>
        	</thead>
        	<tbody id="drivers_tbl">
				<?php foreach($nt_drivers as $drivers){ ?>
					<?php if($drivers->nt_driver_status=='not approved'){ ?>
				<tr >
                    <td><?php echo $drivers->main_id; ?></td>
                    <td><?php echo date("d/m/Y H:i", strtotime($drivers->last_modified)); ?></td>
                    <td><?php echo $drivers->driver_number; ?></td>
                    <!--
                    <td><?php echo $drivers->nt_driver_status; ?></td>
                    -->
                    <td><span class="label label-important">Ikke Godkjent</span></td>
                    <td><?php echo $drivers->employee_id; ?></td>
                    <td class="option btn-group">
							<a data-target="#myModal" role="button" class="btn btn-mini" data-toggle="modal" href="<?php echo base_url('norgestaxi/edit/driver/'.$drivers->main_id); ?>">Rediger</a>
					</td>
				</tr>
				<?php } ?>
				<?php } ?>
     		</tbody>   
    	</table>
    	</div>
    </div>     
    </div>
    <?php } ?>
    <br clear="all">

</div>
<script>
		
		
		
		
	$(document).ready(function(){	
		$('#reports_daterange, #cars_daterange, #drivers_daterange').daterangepicker({
                        ranges: {
                           'Idag': [new Date(), new Date()],
                           'Igår': [moment().subtract('days', 1), moment().subtract('days', 1)],
                           'Siste 7 dager': [moment().subtract('days', 6), new Date()],
                           'Siste 30 dager': [moment().subtract('days', 29), new Date()],
                           'Denne måned': [moment().startOf('month'), moment().endOf('month')],
                           'Siste måned': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                        },
                        opens: 'left',
                        format: 'DD/MM/YYYY',
                        separator: ' - ',
                        startDate: moment().subtract('days', 29),
                        endDate: new Date(),
                        minDate: '01/01/2012',
                        maxDate: '12/31/2030',
                        locale: {
                            applyLabel: 'Ok',
                            fromLabel: 'Fra',
                            toLabel: 'Til',
                            customRangeLabel: 'Egendefinert',
                            daysOfWeek: ['Sø', 'Ma', 'Ti', 'On', 'To', 'Fr','Lø'],
                            monthNames: ['Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'],
                            firstDay: 1
                        },
                        showWeekNumbers: true,
                        buttonClasses: ['btn-danger'],
                        dateLimit: false
                     },
                     function(start, end) {
                        $('#reports_daterange span, #cars_daterange span, #drivers_daterange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                     }
         );
	});
</script>