<div id="response_modal" class="modal hide fade in" style="display: block;" aria-hidden="false">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Rediger - Bil Kontroll</h3>
  </div>
  <div class="modal-body">
  	<div class="modal-inner">
		<input type="hidden" id="car_control_id" value="<?php echo $data->car_control_id; ?>" />
		<input type="hidden" id="nt_cars_id" value="<?php echo $data->nt_cars_id; ?>" />
	<label>Bilreg. nr:</label>
		<?php 
			foreach($nt_carplates as $a){
				if($a->id==$data->nt_carplate_id){
					$carplate = $a->plate_chars;
				}
			}
		?>
		<?php 
			foreach($nt_cargrants as $a){
				if($a->id==$data->nt_cargrant_id){
					$cargrant = $a->car_grants;
				}
			}
		?>
		<input type="text" id="nt_cars_plate" id="carplates_type_ahead" value="<?php echo $carplate; ?>" /><br/>
		<label>Løyvenr:</label>
		<input type="text" id="nt_cargrants" id="cargrants_type_ahead" value="<?php echo $cargrant; ?>" />	<br/>
		<input type="checkbox" id="kp_1" <?php if($data->kp_1==1){ ?>checked<?php } ?> /> Taklampe
		<br/> 
		<input type="checkbox" id="kp_2" <?php if($data->kp_2==1){ ?>checked<?php } ?> /> Ikke Skadet-/møkkete bil 
		<br/>
		<input type="checkbox" id="kp_3" <?php if($data->kp_3==1){ ?>checked<?php } ?> /> Kartbok 
		</br>
		</br>
		<span> Kontroll av logo </span>
		</br>
		<input type="checkbox" id="kp_4" <?php if($data->kp_4==1){ ?>checked<?php } ?> /> Logo fordør og tlf. nr bakdør førerside 
		<br/>
		<input type="checkbox" id="kp_5" <?php if($data->kp_5==1){ ?>checked<?php } ?> /> Logo fordør og tlf. nr bakdør passasjerside 
		<br/>
		<input type="checkbox" id="kp_6" <?php if($data->kp_6==1){ ?>checked<?php } ?> /> Logo og tlf på bilens bakside 
		<br/>
		<input type="checkbox" id="kp_7" <?php if($data->kp_7==1){ ?>checked<?php } ?> /> Airportklistremerke 
		<br/>
		<input type="checkbox" id="kp_8" <?php if($data->kp_8==1){ ?>checked<?php } ?> /> Taksoblat  
		<br/>
		<br/>
		<textarea id="kp_comment" placeholder="Kommentarfelt" cols="10" rows="5"><?php echo $data->comments; ?></textarea>
</div>

  <div class="modal-footer">
	<div id="callback"></div>
    <button id="btn_sbmt" class="btn btn-primary">Lagre Endringer</button>
  </div>
</div>
  <script>
		$(document).ready(function(){
		
		$('#carplates_type_ahead').typeahead([
			{
			name: 'carplates',
			local: [ 
			<?php foreach($nt_carplates as $nt_carplate){ ?>
				"<?php echo $nt_carplate->plate_chars; ?>",
			<?php } ?>
			]
			}
		]);		
		
		$('#cargrants_type_ahead').typeahead([
			{
			name: 'cargrants',
			local: [ 
			<?php foreach($nt_cargrants as $nt_grant){ ?>
				"<?php echo $nt_grant->car_grants; ?>",
			<?php } ?>
			]
			}
		]);
		});
	</script>
	<style>
		
		.block{
			display: block;
		}
		.tt-suggestions{
			background-color: #fff;
			width: 300px;
			border: 1px solid #555;
		}
		
		.tt-suggestion p{
			margin: 0px;
			padding: 5px 10px;
		}
		
	</style>
	<script>
	$("#btn_sbmt").click(function(){
		var kp1 = 0,kp2 = 0,kp3 = 0,kp4 = 0,kp5 = 0,kp6 = 0,kp7 = 0,kp8 = 0;
		if($('#kp_1').attr('checked')){
			kp1 = 1;
		}
		if($('#kp_2').attr('checked')){
			kp2 = 1;
		}
		if($('#kp_3').attr('checked')){
			kp3 = 1;
		}
		if($('#kp_4').attr('checked')){
			kp4 = 1;
		}
		if($('#kp_5').attr('checked')){
			kp5 = 1;
		}
		if($('#kp_6').attr('checked')){
			kp6 = 1;
		}
		if($('#kp_7').attr('checked')){
			kp7 = 1;
		}	
		if($('#kp_8').attr('checked')){
			kp8 = 1;
		}
				
	  $.post("<?php echo base_url('norgestaxi/edit/car/'.$data->report_id); ?>",{car_control_id: $('#car_control_id').val(), nt_cars_id: $('#nt_cars_id').val(),kp_comment: $('#kp_comment').val(),kp_1: kp1,kp_2: kp2,kp_3: kp3,kp_4: kp4,kp_5: kp5,kp_6: kp6,kp_7: kp7,kp_8: kp8,nt_cargrants: $('#nt_cargrants').val(),nt_cars_plate: $('#nt_cars_plate').val()},function(ret){
			$('#callback').html('updated');
	  });
	});

</script>	