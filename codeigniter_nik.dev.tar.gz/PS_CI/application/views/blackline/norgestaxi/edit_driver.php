
<div id="response_modal" class="modal hide fade in" style="display: block;" aria-hidden="false">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Rediger - Sjåfør Kontroll</h3>
  </div>
  <div class="modal-body">
  <div class="modal-inner">
		<input type="hidden" id="driver_control_id" value="<?php echo $data->nt_driver_control_id; ?>" />
		<input type="hidden" id="drivers_data_id" value="<?php echo $data->dd_id; ?>" />
		<label>Sjåførnr:</label>
		<?php foreach($nt_drivers_dd as $a){
			if($a->id==$data->driver_id){
				$the_value = $a->driver_number;
			}
		} ?>
		<input type="text" id="nt_driver" class="type_ahead" value="<?php echo $the_value; ?>" /><br/>
		<input type="checkbox" id="kps_1" <?php if($data->kps_1==1){ ?>checked<?php } ?> /> Tilfredsstillende uniform
		<br/>
		<input type="checkbox" id="kps_2" <?php if($data->kps_2==1){ ?>checked<?php } ?> /> Gyldig ID-kort
		<br/>
		<input type="checkbox" id="kps_3" <?php if($data->kps_3==1){ ?>checked<?php } ?> /> ID-kort synlig 
		<br/>
		<input type="checkbox" id="kps_4" <?php if($data->kps_4==1){ ?>checked<?php } ?> /> Korrekt kopi siste tur 
		<br/>
		<br/>
		<textarea id="kps_comment" placeholder="Kommentarfelt" rows="10" cols="25"><?php echo $data->comments; ?></textarea>
	</div>


  <div class="modal-footer">
	<div id="callback"></div>
    <button id="btn_submit" class="btn btn-primary">Lagre Endringer</button>
  </div>
</div>
<script>
	$("#btn_submit").click(function(){
			var kps1 = 0,kps2 = 0,kps3 = 0,kps4 = 0,kps5 = 0,kps6 = 0;
		if($('#kps_1').attr('checked')){
			kps1 = 1;
		}
		if($('#kps_2').attr('checked')){
			kps2 = 1;
		}
		if($('#kps_3').attr('checked')){
			kps3 = 1;
		}
		if($('#kps_4').attr('checked')){
			kps4 = 1;
		}
	  $.post("<?php echo base_url('norgestaxi/edit/driver/'.$data->report_id); ?>",{kps_comment: $('#kps_comment').val(),kps_1: kps1,kps_2: kps2,kps_3: kps3,kps_4: kps4,kps_5: kps5,kps_6: kps6,driver_control_id: $('#driver_control_id').val(),drivers_data_id: $('#drivers_data_id').val(),nt_driver: $('#nt_driver').val()},function(ret){
			$('#callback').html('Updated');
	  });
	});

</script>
<script>
		$(document).ready(function(){
		$('.type_ahead').typeahead([
			{
			name: 'drivers',
			local: [ 
			<?php foreach($nt_drivers_dd as $nt_drivers){ ?>
				"<?php echo $nt_drivers->driver_number; ?>",
			<?php } ?>
			]
			}
		]);
		});
</script>
<style>
	
		.block{
			display: block;
		}
		.tt-suggestions{
			background-color: #fff;
			width: 300px;
			border: 1px solid #555;
		}
		
		.tt-suggestion p{
			margin: 0px;
			padding: 5px 10px;
		}
		
	</style>