<div id="main">
        <div class="visible-phone"><br/></div>
        <a href="#" class="btn" data-toggle="modal"><i class="icon-pencil"></i> <?=$this->lang->line('application_add_new_webnews');?></a>
        <div class="table_head"><h6><i class="icon-th"></i><?=$this->lang->line('application_webnews');?></h6></div>
        

</div>