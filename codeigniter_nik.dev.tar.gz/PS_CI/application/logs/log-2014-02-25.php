ERROR - 2014-02-25 18:40:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter_nik`.`alex_main_report`, CONSTRAINT `alex_main_report_ibfk_23` FOREIGN KEY (`service_id`) REFERENCES `alex_service` (`id`))
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:40:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:40:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:40:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:40:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:40:46 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:42:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:42:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:42:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:42:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:42:08 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:43:48 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter_nik`.`alex_main_report`, CONSTRAINT `alex_main_report_ibfk_23` FOREIGN KEY (`service_id`) REFERENCES `alex_service` (`id`))
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:48:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:48:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:48:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:48:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:48:33 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:48:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter_nik`.`alex_main_report`, CONSTRAINT `alex_main_report_ibfk_23` FOREIGN KEY (`service_id`) REFERENCES `alex_service` (`id`))
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:52:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:52:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:52:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:52:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:52:07 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:55:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter_nik`.`alex_main_report`, CONSTRAINT `alex_main_report_ibfk_23` FOREIGN KEY (`service_id`) REFERENCES `alex_service` (`id`))
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:55:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:55:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:55:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:55:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:55:34 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:55:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:55:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:55:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:55:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:55:42 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:55:48 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:55:48 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:55:48 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:55:48 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:55:48 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:58:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:58:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:58:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:58:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:58:02 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:58:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:58:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:58:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:58:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:58:07 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 18:58:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 18:58:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 18:58:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 18:58:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "content_one"
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "content_two"
ERROR - 2014-02-25 18:58:09 --> Could not find the language line "application_create"
ERROR - 2014-02-25 18:58:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter_nik`.`alex_main_report`, CONSTRAINT `alex_main_report_ibfk_23` FOREIGN KEY (`service_id`) REFERENCES `alex_service` (`id`))
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:00:53 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:00:53 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:00:53 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:00:53 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:00:53 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:01:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:01:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:01:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:01:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:01:01 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:01:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:01:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:01:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:01:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:01:06 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:21:55 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:21:55 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:21:55 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:21:55 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:21:55 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:21:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:21:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:21:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:21:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:21:58 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:22:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:22:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:22:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:22:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:22:03 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:22:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:22:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:22:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:22:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:22:19 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:22:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:22:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:22:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:22:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:22:23 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:24:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:24:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:24:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:24:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:24:27 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:27:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:27:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:27:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:27:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:27:13 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:27:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:27:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:27:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:27:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:27:39 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:28:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:28:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:28:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:28:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:28:01 --> Could not find the language line "application_create"
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:28:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:28:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:28:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:28:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:28:47 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:36:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:36:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:36:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:36:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:36:57 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:36:59 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 19:37:01 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 19:37:07 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 19:37:16 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 19:37:26 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:39:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:39:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:39:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:39:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:39:38 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:40:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:40:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:40:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:40:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::625:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:40:37 --> Could not find the language line "content_two"
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 19:54:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::649:: didnot translated - application_Sentrum
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 19:54:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::649:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 19:54:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::649:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 19:54:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::649:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "content_one"
ERROR - 2014-02-25 19:54:22 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:15:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:15:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:15:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:15:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:15:44 --> Could not find the language line "application_create"
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:16:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:16:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:16:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:16:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:16:04 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:16:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:16:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:16:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:16:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::679:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:16:28 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:17:54 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:18:18 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:19:46 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:21:18 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:21:34 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:22:12 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:23:40 --> Query error: Lost connection to MySQL server during query
ERROR - 2014-02-25 20:23:48 --> Query error: Query execution was interrupted
ERROR - 2014-02-25 20:23:49 --> Query error: Query execution was interrupted
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:32:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:32:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:32:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:32:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:32:47 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:32:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:32:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:32:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:32:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:32:49 --> Could not find the language line "application_create"
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:33:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:33:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:33:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:33:06 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:33:06 --> Could not find the language line "application_create"
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:33:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:33:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:33:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:33:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::686:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:33:11 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:35:17 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:17 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:20 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:20 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:24 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:25 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:35:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::680:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:35:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::680:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:35:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::680:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:35:28 -->        !!!  Norgestaxi_v2::_getTranslateEverything::680:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:35:28 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:35:33 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:33 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:37 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:41 --> Severity: Warning  --> mysql_connect(): Access denied for user 'proffwqr_fc2pro'@'localhost' (using password: YES) /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/employees/all.php 11
ERROR - 2014-02-25 20:35:41 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:44 --> Severity: Warning  --> mysql_connect(): Access denied for user 'proffwqr_fc2pro'@'localhost' (using password: YES) /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/employees/all.php 11
ERROR - 2014-02-25 20:35:45 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:46 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:35:48 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:49 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:35:50 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:51 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:55 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:56 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:58 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:35:58 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:36:06 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:36:07 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:37:51 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 20:45:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::681:: didnot translated - application_Sentrum
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 20:45:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::681:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 20:45:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::681:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 20:45:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::681:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "content_one"
ERROR - 2014-02-25 20:45:50 --> Could not find the language line "content_two"
ERROR - 2014-02-25 20:46:57 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:46:58 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:47:39 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:47:39 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:48:57 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:48:59 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:06 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:08 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:21 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:23 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:28 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:49:30 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 20:52:34 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 21:09:04 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 21:09:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 21:09:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 21:09:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 21:09:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "content_one"
ERROR - 2014-02-25 21:09:15 --> Could not find the language line "content_two"
ERROR - 2014-02-25 21:09:19 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 21:09:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 21:09:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 21:09:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 21:09:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "content_one"
ERROR - 2014-02-25 21:09:27 --> Could not find the language line "content_two"
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 21:14:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 21:14:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 21:14:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 21:14:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "content_one"
ERROR - 2014-02-25 21:14:56 --> Could not find the language line "content_two"
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 21:15:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 21:15:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 21:15:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 21:15:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "content_one"
ERROR - 2014-02-25 21:15:19 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:23:33 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:23:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:23:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:23:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:23:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:23:38 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:23:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:23:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:23:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:23:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:23:51 --> Could not find the language line "application_create"
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:24:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:24:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:24:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:24:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:24:09 --> Could not find the language line "application_create"
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:24:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:24:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:24:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:24:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:24:14 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:54:27 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:54:59 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:56:12 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:56:12 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:56:12 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:56:12 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:56:12 --> Could not find the language line "content_two"
ERROR - 2014-02-25 22:59:22 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 22:59:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 22:59:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 22:59:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 22:59:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "content_one"
ERROR - 2014-02-25 22:59:32 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:06:13 --> Could not find the language line "application_service"
ERROR - 2014-02-25 23:10:58 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:11:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:11:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:11:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:11:01 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:11:01 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:11:30 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:12:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:12:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:12:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:12:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:12:03 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:12:12 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:12:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:12:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:12:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:12:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:12:23 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:13:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:13:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:13:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:13:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::693:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:13:35 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:15:28 --> Could not find the language line "application_usercss"
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:15:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:15:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:15:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:15:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:15:32 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:16:40 --> Could not find the language line "application_usercss"
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:16:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:16:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:16:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:16:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::694:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:16:44 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:17:09 --> Could not find the language line "application_favicon.ico"
ERROR - 2014-02-25 23:17:09 --> Could not find the language line "application_favicon.ico"
ERROR - 2014-02-25 23:17:14 --> Could not find the language line "application_usercss"
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:17:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:17:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:17:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:17:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:17:18 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:17:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:17:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:17:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:17:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:17:45 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:21:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:21:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:21:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:21:03 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:21:03 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:21:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:21:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:21:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:21:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:21:40 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:25:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:25:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:25:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:25:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:25:33 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:27:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:27:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:27:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:27:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:27:33 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:32:27 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:32:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:32:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:32:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:32:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::695:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:32:39 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:41:44 --> Could not find the language line "application_Date_Time_2"
ERROR - 2014-02-25 23:41:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::717:: didnot translated - application_Date_Time_2
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:41:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:41:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:41:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:41:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:41:45 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:47:32 --> Query error: Unknown column 'status_name' in 'field list'
ERROR - 2014-02-25 23:48:09 --> Query error: Unknown column 'status_name' in 'field list'
ERROR - 2014-02-25 23:54:45 --> Could not find the language line "application_Date_Time_2"
ERROR - 2014-02-25 23:54:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::717:: didnot translated - application_Date_Time_2
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:54:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:54:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:54:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:54:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:54:46 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:55:09 --> Could not find the language line "application_Date_Time_2"
ERROR - 2014-02-25 23:55:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::717:: didnot translated - application_Date_Time_2
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:55:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:55:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:55:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:55:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:55:10 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:56:16 --> Could not find the language line "application_Date_Time_2"
ERROR - 2014-02-25 23:56:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::717:: didnot translated - application_Date_Time_2
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:56:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:56:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:56:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:56:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:56:20 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:59:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:59:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:59:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:59:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:59:45 --> Could not find the language line "content_two"
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 23:59:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Sentrum
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 23:59:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 23:59:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "application_Øvrig Oslo"
ERROR - 2014-02-25 23:59:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::708:: didnot translated - application_Øvrig Oslo
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "content_one"
ERROR - 2014-02-25 23:59:59 --> Could not find the language line "content_two"
