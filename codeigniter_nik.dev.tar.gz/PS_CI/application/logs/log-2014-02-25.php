<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-02-25 08:53:47 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 08:53:47 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:53:49 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 08:53:49 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:16 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:17 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:34 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:35 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:36 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:54:40 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:41 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:44 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:56 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:54:59 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:54:59 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:55:21 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:55:22 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:55:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:55:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:55:31 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:55:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:55:43 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:55:46 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:55:47 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:55:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:56:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:56:04 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:56:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:56:18 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:56:22 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:56:23 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:56:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:56:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:56:58 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 08:58:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:58:04 --> Could not find the language line "application_create"
ERROR - 2014-02-25 08:58:50 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 08:58:51 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 08:58:51 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:00:18 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:00:20 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:00:20 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:00:43 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:00:44 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:00:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:00 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:01 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:01 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:32 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:33 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:33 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:37 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:37 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:42 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:46 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:01:47 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:01:47 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:03:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:03:42 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:03:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:06:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:06:44 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:06:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:07:12 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:07:13 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:07:13 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:07:37 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:07:38 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:07:38 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:53:13 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:53:13 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:53:14 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:53:14 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:53:20 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 09:53:20 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 09:53:20 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:00:26 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:00:26 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:00:28 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:00:28 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:00:38 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:00:40 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:00:40 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:00:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:04:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:04:33 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:04:33 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:04:42 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:04:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:04:56 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:04:56 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:05:01 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:05:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:05:11 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:05:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:05:17 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:05:17 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:05:27 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:05:27 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:05:57 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:05:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:06:18 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:06:18 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:06:19 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:06:19 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:06:23 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:06:41 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 10:06:42 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 10:06:42 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 10:09:26 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:11:48 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 427
ERROR - 2014-02-25 10:11:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 427
ERROR - 2014-02-25 10:13:48 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 427
ERROR - 2014-02-25 10:13:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 427
ERROR - 2014-02-25 10:17:23 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:17:50 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:17:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:17:58 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:17:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 184
ERROR - 2014-02-25 10:18:13 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:18:13 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:18:27 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 185
ERROR - 2014-02-25 10:18:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 185
ERROR - 2014-02-25 10:18:33 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 185
ERROR - 2014-02-25 10:18:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 185
ERROR - 2014-02-25 10:18:43 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:18:43 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:19:02 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:19:02 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:19:28 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:19:29 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:19:29 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:20:27 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 183
ERROR - 2014-02-25 10:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 183
ERROR - 2014-02-25 10:20:42 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:20:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:20:42 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 183
ERROR - 2014-02-25 10:20:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 183
ERROR - 2014-02-25 10:20:57 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:20:57 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:21:02 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 123
ERROR - 2014-02-25 10:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 123
ERROR - 2014-02-25 10:21:15 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 116
ERROR - 2014-02-25 10:21:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 116
ERROR - 2014-02-25 10:21:27 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 68
ERROR - 2014-02-25 10:21:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 68
ERROR - 2014-02-25 10:21:41 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:21:41 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:21:43 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 55
ERROR - 2014-02-25 10:21:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 55
ERROR - 2014-02-25 10:21:55 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 38
ERROR - 2014-02-25 10:21:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 38
ERROR - 2014-02-25 10:22:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:22:37 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:22:37 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:23:30 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:23:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:23:35 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:23:35 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:23:38 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:23:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:23:38 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:23:39 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:23:39 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:24:19 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:24:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:24:20 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:24:20 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:24:37 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:28:40 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:28:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:28:40 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:28:43 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:28:43 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:29:34 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:29:34 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:29:36 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:29:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:30:34 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:30:34 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:30:36 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:30:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:07 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:07 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:09 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:36:09 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:44 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:47 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:36:47 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:55 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:36:55 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:36:56 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:36:56 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:40:52 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:40:52 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:40:52 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:40:52 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:41:04 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:41:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:41:04 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:41:05 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:41:05 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:41:15 --> Severity: Notice  --> Undefined variable: tbl_dd /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/statistics/dashboard.php 426
ERROR - 2014-02-25 10:41:15 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:41:16 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 10:41:16 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:45:51 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 10:45:52 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 10:45:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 10:45:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:45:54 --> Could not find the language line "application_create"
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 10:46:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 10:46:14 --> Could not find the language line "application_create"
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 11:07:41 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 11:07:41 --> Could not find the language line "application_create"
ERROR - 2014-02-25 11:09:32 -->        !!!  Norgestaxi_v2::_validateData::1022:: not valid value -- 25/02/2014d criteria date
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_validateData::1017:: not valid value -- 25/02/2014d criteria date
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 11:12:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 11:12:56 --> Could not find the language line "application_create"
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 11:17:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 11:17:50 --> Could not find the language line "application_create"
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 11:18:23 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 11:18:23 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:27:01 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 14:27:01 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:27:02 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 14:27:02 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:27:04 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:27:05 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:27:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:27:09 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:27:09 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:39:22 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:39:22 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:44:13 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:44:13 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:46:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:46:34 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:47:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:47:30 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:47:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:47:39 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 5
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:48:43 -->        !!!  Norgestaxi_v2::_getTranslateEverything::611:: didnot translated - application_location 6
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:48:43 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 5
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:52:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 6
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:52:32 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 5
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:53:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 6
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:53:40 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 5
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:54:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::613:: didnot translated - application_location 6
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:54:02 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 5
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:55:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 6
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:55:17 --> Could not find the language line "application_create"
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Sentrum
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 5
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 14:56:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 6
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 14:56:32 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 5
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:11:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::615:: didnot translated - application_location 6
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:11:33 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:21:11 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:21:11 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:23:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:23:24 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:24:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:24:19 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_location 5
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:27:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::617:: didnot translated - application_location 6
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:27:44 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:27:45 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 15:27:45 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:27:50 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 15:27:50 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:28:08 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:28:08 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:30:49 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:30:49 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 5
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:35:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::616:: didnot translated - application_location 6
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:35:07 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:40:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:40:57 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:40:58 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:40:58 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:41:27 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:41:27 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:41:52 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:41:54 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:41:54 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:42:33 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:42:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:42:35 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:42:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:42:44 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:42:44 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:42:45 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:42:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:42:47 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:43:11 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:43:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:43:15 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:43:35 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:43:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:43:40 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:44:42 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:44:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:44:47 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:45:11 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:45:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:45:15 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:46:12 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:46:16 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:46:16 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:46:30 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:46:30 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:46:41 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:46:46 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:46:46 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:47:10 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:47:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:47:15 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:48:27 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:48:31 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:48:31 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:50:10 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:50:10 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:50:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:50:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:50:36 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:50:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:50:37 --> Could not find the language line "application_create"
ERROR - 2014-02-25 15:50:46 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:50:50 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:50:50 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:51:48 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:51:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:51:52 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:52:29 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:52:34 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:52:34 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:53:34 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:53:39 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:53:39 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:54:02 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:54:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:54:07 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:55:02 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:55:07 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:55:07 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:57:29 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:57:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:57:33 --> Could not find the language line "content_two"
ERROR - 2014-02-25 15:59:21 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 15:59:25 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "content_one"
ERROR - 2014-02-25 15:59:25 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:00:25 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:00:29 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:00:29 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:00:57 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:01:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:01:02 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:01:16 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:01:21 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:01:21 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:01:46 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:01:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:01:51 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:04:03 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:04:05 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:04:05 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:04:45 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:04:45 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:04:57 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:04:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:04:58 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:06:13 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:06:14 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:06:14 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:06:26 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 16:06:26 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:27 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 16:06:27 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:29 --> Severity: Notice  --> Undefined variable: line1 /home/alex/websites/codeigniter_nik.dev/PS_CI/application/views/blackline/dashboard/dashboard.php 118
ERROR - 2014-02-25 16:06:29 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:06:32 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:06:32 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:06:46 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:06:47 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:06:47 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:06:51 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:06:52 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:06:52 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:07:25 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:07:26 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:07:26 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:08:18 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:08:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:08:19 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:08:37 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:08:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:08:38 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:08:50 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:08:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:08:51 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:09:22 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:09:24 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:09:24 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:09:33 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:09:33 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:11:37 -->        !!!  Norgestaxi_v2::_validateData::1018:: not valid value --  criteria date
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:11:38 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:11:38 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:12:03 -->        !!!  Norgestaxi_v2::_validateData::1018:: not valid value --  criteria date
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:12:04 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:12:04 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:19:19 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:19:19 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:19:35 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:19:35 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:20:01 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:02 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:02 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:36 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:37 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:37 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:40 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:40 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:51 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:51 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:20:55 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:56 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:56 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:20:58 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:20:58 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:21:15 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:21:15 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:21:17 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:21:18 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:21:18 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:21:57 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:21:57 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:22:17 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:22:17 --> Could not find the language line "application_create"
ERROR - 2014-02-25 16:22:19 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:22:20 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:22:20 --> Could not find the language line "content_two"
ERROR - 2014-02-25 16:22:35 --> Could not find the language line "application_statisticsv2"
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_Sentrum"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Sentrum
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_Ullevål Sykehus"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Ullevål Sykehus
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_Rikshospitalet"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Rikshospitalet
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_Oslo Øvrig"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_Oslo Øvrig
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_location 5"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 5
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "application_location 6"
ERROR - 2014-02-25 16:22:36 -->        !!!  Norgestaxi_v2::_getTranslateEverything::623:: didnot translated - application_location 6
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "content_one"
ERROR - 2014-02-25 16:22:36 --> Could not find the language line "content_two"
