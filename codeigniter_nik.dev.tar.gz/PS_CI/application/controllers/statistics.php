<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Statistics extends MY_Controller
{
	var $total = 0;
	function __construct()
	{
		parent::__construct();


		$access = FALSE;
		if($this->user || $this->client){
			foreach ($this->view_data['menu'] as $key => $value) {
				if($value->link == "statistics"){
					$access = TRUE;
				}
			}
			if(!($access)){redirect($this->view_data['menu'][0]->link);}

		}else{
			redirect('login');
		}

	}

	function index(){
		$str = '';
		$str2 = '';
		if($this->user){
			//load models
			$this->load->model('companies_model');
			$this->load->model('shiftjournal_model');
			$this->load->model('objectcat_model');
			$this->load->model('shiftjournalcode_model');
			$objects = $this->shiftjournal_model->fetch_all_objects();
			$total = $this->shiftjournal_model->total_shiftjournal();
			$names = array('Anmeldelser','Bortvisning','Observasjoner/Tilsnakk av personer','Serviceoppdrag','Åpningsavvik');
			$thedate = explode(' ',$this->shiftjournal_model->get_min_year());
			$thedate = explode('-',$thedate[0]);
			$thedatemax = explode(' ',$this->shiftjournal_model->get_max_year());
			$thedatemax = explode('-',$thedatemax[0]);
			$piegraph = '';
			$callings = $this->shiftjournal_model->fetch_all_callings();
			if(($this->input->post('pie') && $this->input->post('pie')!='Velg Objekt') ){
				if($this->input->post('pie_date') && $this->input->post('pie_date')!='All'){
					foreach($callings as $calling){
						$piegraph .= '["'.$calling->calling.'",'.$this->shiftjournal_model->get_calling_count_by_object_date($calling->calling,$this->input->post('pie'))/$total.'],';
					}
				}else{
					foreach($callings as $calling){
						$piegraph .= '["'.$calling->calling.'",'.$this->shiftjournal_model->get_calling_count_by_object($calling->calling,$this->input->post('pie'))/$total.'],';
					}
				}
			}else{
				if($this->input->post('pie_date') && $this->input->post('pie_date')!='All'){
					foreach($callings as $calling){
						$piegraph .= '["'.$calling->calling.'",'.$this->shiftjournal_model->get_calling_count_date($calling->calling)/$total.'],';
					}
				}else{
					foreach($callings as $calling){
						$piegraph .= '["'.$calling->calling.'",'.$this->shiftjournal_model->get_calling_count($calling->calling)/$total.'],';
					}
				}
			}

			//all data
			if(($this->input->post('tableone_object') && $this->input->post('tableone_object')!='Velg Objekt') && ($this->input->post('tableone_company') && $this->input->post('tableone_company')!='All Companies')){
				$tblonedata = $this->shiftjournal_model->fetch_all_statistics_by_company();
			}else if(($this->input->post('tableone_object') && $this->input->post('tableone_object')!='Velg Objekt')){
				$tblonedata = $this->shiftjournal_model->fetch_all_statistics_by_object();
			}else{
				$tblonedata = $this->shiftjournal_model->fetch_all_statistics();
			}


			$tbldata = $this->shiftjournal_model->fetch_all_statistics();
			//graph one
			if($this->input->post('graphone_object')== 'Velg Objekt' || !$this->input->post('graphone_object')){
				foreach($tbldata as $taskc){
						if(in_array($taskc->taskcode,$names)){
						$str .= '{';
						$str .= 'name: "'.$taskc->taskcode.'",';
						$str .= 'data: [';
							for($x=1;$x<=12;$x++){
								$d = $this->get_by_month($x,$taskc->taskcode);
								if($d==""){
									$str .= '0,';
								}else{
									$str .= $d.',';
								}
							}
						$str .= ']';
						$str .= '},';
						}
				}
			}else{
				$ids = $this->objectcat_model->get_shiftcodejournal_ids($this->input->post('graphone_object'));
				$ids = explode(',',$ids->statistics_taskcode_access);
				$taskcodes = $this->shiftjournalcode_model->fetch_data_ids($ids);
				$gocompanies = $this->shiftjournal_model->fetch_companies_by_object($this->input->post('graphone_object'));

				$company_arr = array();
				foreach($gocompanies as $company){
					$company_arr[] = $company->company;
				}
				if($this->input->post('graphone_company')== 'All Company' || !$this->input->post('graphone_company')){
					foreach($taskcodes as $taskcode){
						$str .= '{';
						$str .= 'name: "'.$taskcode->codedescription.'",';
						$str .= 'data: [';
							for($x=1;$x<=12;$x++){
								$d = $this->get_by_month($x,$taskcode->codedescription,$company_arr);
								if($d==""){
									$str .= '0,';
								}else{
									$str .= $d.',';
								}
							}
							$str .= ']';
							$str .= '},';

						//echo $str;
					}
				}else{
					foreach($taskcodes as $taskcode){
						$str .= '{';
						$str .= 'name: "'.$taskcode->codedescription.'",';
						$str .= 'data: [';
							for($x=1;$x<=12;$x++){
								$d = $this->get_by_month($x,$taskcode->codedescription,null,$this->input->post('graphone_company'));
								if($d==""){
									$str .= '0,';
								}else{
									$str .= $d.',';
								}
							}
							$str .= ']';
							$str .= '},';
					}
				}
			}

				//graph two
				if($this->input->post('graphtwo_object')== 'Velg Objekt' || !$this->input->post('graphtwo_object')){
					foreach($tbldata as $taskc){
						if(in_array($taskc->taskcode,$names)){
						$str2 .= '{';
						$str2 .= 'name: "'.$taskc->taskcode.'",';
						$str2 .= 'data: [';
							for($x=1;$x<=12;$x++){
								$d = $this->get_by_month_rep($x,$taskc->taskcode);
								if($d==0){
									$str2 .= '0,';
								}else{
									$str2 .= $d.',';
								}
							}
						$str2 .= ']';
						$str2 .= '},';
						}
					}
				}else{
					$ids = $this->objectcat_model->get_shiftcodejournal_ids($this->input->post('graphtwo_object'));
					$ids = explode(',',$ids->statistics_taskcode_access);
					$taskcodes = $this->shiftjournalcode_model->fetch_data_ids($ids);
					$gtcompanies = $this->shiftjournal_model->fetch_companies_by_object($this->input->post('graphtwo_object'));
					$company_arr = array();
					foreach($gtcompanies as $company){
						$company_arr[] = $company->company;
					}
					if($this->input->post('graphtwo_company')== 'All Company' || !$this->input->post('graphtwo_company')){
						foreach($taskcodes as $taskcode){
							$str2 .= '{';
							$str2 .= 'name: "'.$taskcode->codedescription.'",';
							$str2 .= 'data: [';
								for($x=1;$x<=12;$x++){
									$d = $this->get_by_month_rep($x,$taskcode->codedescription,$company_arr);
									if($d==0){
										$str2 .= '0,';
									}else{
										$str2 .= $d.',';
									}
								}
								$str2 .= ']';
								$str2 .= '},';

							//echo $str;
						}
					}else{
						foreach($taskcodes as $taskcode){
							$str2 .= '{';
							$str2 .= 'name: "'.$taskcode->codedescription.'",';
							$str2 .= 'data: [';
								for($x=1;$x<=12;$x++){
									$d = $this->get_by_month_rep($x,$taskcode->codedescription,null,$this->input->post('graphtwo_company'));
									if($d==0){
										$str2 .= '0,';
									}else{
										$str2 .= $d.',';
									}
								}
								$str2 .= ']';
								$str2 .= '},';
						}
					}
				}


				//table
				if($this->input->post('tableone_object')== 'Velg Objekt' || !$this->input->post('tableone_object')){
				}else{
					$tblcompanies = $this->shiftjournal_model->fetch_companies_by_object($this->input->post('tableone_object'));
				}
		}

			$this->view_data["dropdowns"] = $objects;
			if(isset($gocompanies)){ $this->view_data["graphone_companies"] = $gocompanies; }
			if(isset($gtcompanies)){ $this->view_data["graphtwo_companies"] = $gtcompanies; }
			if(isset($tblcompanies)){ $this->view_data["tbl_dd"] = $tblcompanies; }
			$this->view_data["piegraph"] = $piegraph;
			$this->view_data["barchart2"] = $str;
			$this->view_data["taskcodes"] = $tbldata;
			$this->view_data["tblone"] = $tblonedata;
			$this->view_data["bar_chart"] = $str2;
			$this->view_data["theyearmin"] = $thedate[0];
			$this->view_data["theyearmax"] = $thedatemax[0];
			$this->view_data["themonthmin"] = $thedate[1];
			$this->view_data["themonthmax"] = $thedatemax[1];
			$this->view_data["barchart2_subtitle"] = 'test again';
			$this->content_view = 'statistics/dashboard';
	}



	function filter($year = FALSE){
		if(!$year){ $year = date('Y', time()); }
		$this->load->database();
		$sql = "select invoices.paid_date, sum(invoice_has_items.value*invoice_has_items.amount) as summary FROM invoices, invoice_has_items where invoices.id = invoice_has_items.invoice_id AND invoices.`status` = 'Paid' AND paid_date between '$year-01-01'
AND '$year-12-31' GROUP BY invoices.paid_date";
		$query = $this->db->query($sql);
		$sql = "select invoices.paid_date, sum(invoice_has_items.value*invoice_has_items.amount) as summary FROM invoices, invoice_has_items where invoices.id = invoice_has_items.invoice_id AND invoices.`status` = 'Paid' GROUP BY invoices.paid_date";
		$jan = $this->db->query($sql);
		$this->view_data["stats"] = $query->result();
		$this->view_data["year"] = $year;
		$this->content_view = 'statistics/dashboard';
	}

	public function sort_object($object = NULL,$year = NULL,$month = NULL)
	{
		$this->index(null,null,$year,$month,$object);
	}

	public function sort_year_month($year = NULL,$month = NULL)
	{
		$this->index(null,null,$year,$month);
	}

	public function sort_bar_year_object($bar_year = NULL,$bar_object = NULL)
	{
		$this->index($bar_year,$bar_object);
	}

	public function sort_bar_object($bar_object)
	{
		$this->index(null,$bar_object);
	}


	function filter_table(){
		$this->load->model('shiftjournal_model');
		$ar = array($this->input->post('data'));
		//echo $this->input->post('data');
		$data = $this->shiftjournal_model->fetch_by_object_distinct($ar);
		//print_r($data);
		foreach($data as $a){
			echo '<tr><td>'.$a->taskcode.'</td>';
			echo '<td>'.$a->tsum.'</td></tr>';
		}
		//$this->load->view('blackline/statistics/dropdown_ajax');
		exit;
	}

	function filter_table_total(){
		$total  = 0;
		$this->load->model('shiftjournal_model');
		$ar = array($this->input->post('data'));
		//echo $this->input->post('data');
		$data = $this->shiftjournal_model->fetch_by_object_distinct($ar);
		//print_r($data);
		foreach($data as $a){
			$total += $a->tsum;
		}
		echo $total;
		exit;
	}

	function filter_table_by_daterange(){
		$dates = explode(' - ',$this->input->post('data'));
		//print_r($dates);
		$start = explode('/',$dates[0]);
		$end = explode('/',$dates[1]);
		$start = $start[2].'-'.$start[1].'-'.$start[0];
		$end = $end[2].'-'.$end[1].'-'.$end[0];
		$this->load->model('companies_model');
		$this->load->model('shiftjournal_model');
		if($this->user){
			$datas = $this->shiftjournal_model->admin_fetch_by_data_by_date_range($start,$end);
		}else{
			$cdata = $this->companies_model->get_company_data($this->client->company_id);
			if($cdata->name=='Grønland Torg Drift Næring'){
					$ar = array('Grønlandstorg','Grønlandstunet','Europark');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else if($cdata->name=='Sameiet Grønlandstunet AS'){
					$ar = array('Grønlandstunet');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else if($cdata->name=='Europark AS'){
					$ar = array('Europark');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else{
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,null,$cdata->name);
			}
		}
		foreach($datas as $data){
			echo '<tr>';
			echo '<td>'.$data->taskcode.'</td>';
			echo '<td>'.$data->tsum.'</td>';
			echo '</tr>';
		}
		exit;
	}

	function filter_table_by_daterange_total(){
		$count = 0;
		$dates = explode(' - ',$this->input->post('data'));
		$start = explode('/',$dates[0]);
		$end = explode('/',$dates[1]);
		$start = $start[2].'-'.$start[1].'-'.$start[0];
		$end = $end[2].'-'.$end[1].'-'.$end[0];
		//print_r($dates);
		$this->load->model('companies_model');
		$this->load->model('shiftjournal_model');
		if($this->user){
			$datas = $this->shiftjournal_model->admin_fetch_by_data_by_date_range($start,$end);
		}else{
			$cdata = $this->companies_model->get_company_data($this->client->company_id);
			if($cdata->name=='Grønland Torg Drift Næring'){
					$ar = array('Grønlandstorg','Grønlandstunet','Europark');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else if($cdata->name=='Sameiet Grønlandstunet AS'){
					$ar = array('Grønlandstunet');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else if($cdata->name=='Europark AS'){
					$ar = array('Europark');
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,$ar);
			}else{
					$datas = $this->shiftjournal_model->fetch_by_data_by_date_range($start,$end,null,$cdata->name);
			}
		}
		foreach($datas as $data){
			$count += $data->tsum;
		}
		echo $count;
		exit;
	}

	/*function get_by_month($m,$tc){
		$this->load->model('shiftjournal_model');
		$datas = $this->shiftjournal_model->get_monthly($m,$tc);
		return $datas->tsum;
		exit;
	}*/

	function get_by_month($m,$tc,$companies=null,$company=null){
		$this->load->model('shiftjournal_model');
		if($companies!=null){
			if($this->input->post('graphone_month') && $this->input->post('graphone_month')!="All"){
				if($m==$this->input->post('graphone_month')){
					$datas = $this->shiftjournal_model->get_monthly_rep($m,$tc,$companies);
				}else{
					$datas = null;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly_rep($m,$tc,$companies);
			}
		}else if($company!=null){
			if($this->input->post('graphone_month') && $this->input->post('graphone_month')!="All"){
				if($m==$this->input->post('graphone_month')){
					$datas = $this->shiftjournal_model->get_monthly_rep_with_company($m,$tc,$company);
				}else{
					$datas = null;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly_rep_with_company($m,$tc,$company);
			}
		}else{
			if($this->input->post('graphone_month') && $this->input->post('graphone_month')!="All"){
				if($m==$this->input->post('graphone_month')){
					$datas = $this->shiftjournal_model->get_monthly_rep($m,$tc);
				}else{
					$datas = null;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly_rep($m,$tc);
			}
		}
		return $datas;
		exit;
	}

	function get_by_month_rep($m,$tc,$companies=null,$company=null){
		$this->load->model('shiftjournal_model');
		if($companies!=null){
			if($this->input->post('graphtwo_month') && $this->input->post('graphtwo_month')!="All"){
				if($m==$this->input->post('graphtwo_month')){
					$datas = $this->shiftjournal_model->get_monthly($m,$tc,$companies);
				}else{
					$datas = 0;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly($m,$tc,$companies);
			}
		}else if($company!=null){
			if($this->input->post('graphtwo_month') && $this->input->post('graphtwo_month')!="All"){
				if($m==$this->input->post('graphtwo_month')){
					$datas = $this->shiftjournal_model->get_monthly_with_company($m,$tc,$company);
				}else{
					$datas = 0;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly_with_company($m,$tc,$company);
			}
		}else{
			if($this->input->post('graphtwo_month') && $this->input->post('graphtwo_month')!="All"){
				if($m==$this->input->post('graphtwo_month')){
					$datas = $this->shiftjournal_model->get_monthly($m,$tc);
				}else{
					$datas = 0;
				}
			}else{
				$datas = $this->shiftjournal_model->get_monthly($m,$tc);
			}
		}
		return $datas;
		exit;
	}

	function ajax_call(){
		$this->load->model('shiftjournal_model');
		//$str = '[';
		$arr = array();
		switch($this->input->post('type')){
			case "get_shiftjournal_object": $data = $this->shiftjournal_model->fetch_all_statistics();
											foreach($data as $tdata){
												//$str .= '{';
												//$str .= 'name: "'.$tdata->taskcode.'",';
												//$arr[] = $tdata->taskcode;
												//$str .= 'data: [';
												if($tdata->object==$this->input->post('data')){
												$arr[$tdata->taskcode]['data'] = array();
													for($x=1;$x<=12;$x++){
														$d = $this->get_by_month($x,$tdata->taskcode);
														if($d==""){
															$arr[$tdata->taskcode]['data'][] = 0;
															//$str .= '0,';
														}else{
															$arr[$tdata->taskcode]['data'][] = $d;
															//$str .= $d.',';
														}
													}
												}
												//$str .= ']';
												//$str .= '},';
											}
											//$str = rtrim($str, ",");
											//$str .= ']';
											echo json_encode($arr);
											//print_r($arr);
											exit;
											break;
			default: ;
		}
	}
}
