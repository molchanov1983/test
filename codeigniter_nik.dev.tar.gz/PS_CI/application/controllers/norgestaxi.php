<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Norgestaxi extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('nt_reports_tbl_model');
        $this->load->model('nt_assignments_tbl_model');
        $dcheck = $this->nt_reports_tbl_model->fetch_check();
        foreach ($dcheck as $a) {
            $this->nt_assignments_tbl_model->update($a->main_id);
            if ($a->nt_driver_status == 'approved' && $a->nt_car_status == 'approved' && $a->is_cleared == 1) {
                $this->nt_reports_tbl_model->update_report_status(1, $a->main_id);
            } else {
                $this->nt_reports_tbl_model->update_report_status(0, $a->main_id);
            }
        }


        $access = FALSE;
        if ($this->user || $this->client) {
            foreach ($this->view_data['menu'] as $key => $value) {
                if ($value->link == "norgestaxi") {
                    $access = TRUE;
                }
            }
            if (!($access)) {
                redirect($this->view_data['menu'][0]->link);
            }
        } else {
            redirect('login');
        }
    }

    function index() {
        $this->load->model('nt_cars_tbl_model');
        $this->load->model('nt_drivers_data_tbl_model');
        $this->load->model('nt_reports_tbl_model');
        $this->view_data['nt_cars'] = $this->nt_cars_tbl_model->fetch_for_tbl();
        $this->view_data['nt_drivers'] = $this->nt_drivers_data_tbl_model->fetch_for_tbl();
        $this->view_data['nt_reports'] = $this->nt_reports_tbl_model->fetch_for_tbl();
        //$this->load->model('nt_reports_model');
        //$this->load->model('nt_cars_model');
        //$this->load->model('nt_drivers_model');
        //$this->view_data['nt_reports'] = $this->nt_reports_model->fetch_global();
        //$this->view_data['nt_cars'] = $this->nt_cars_model->fetch_all_unapproved();
        //$this->view_data['nt_drivers'] = $this->nt_drivers_model->fetch_all_unapproved();

        $this->content_view = 'norgestaxi/all';
    }

    function create() {
        if ($_POST) {
            $this->load->model('nt_reports_tbl_model');
            $this->load->model('nt_cars_control_tbl_model');
            $this->load->model('nt_drivers_control_tbl_model');
            $this->load->model('nt_drivers_data_tbl_model');
            $this->load->model('nt_cars_tbl_model');
            $this->load->model('nt_drivers_tbl_model');
            $this->load->model('nt_carplates_tbl_model');
            $this->load->model('nt_car_grants_tbl_model');
            if ($this->nt_drivers_tbl_model->check($this->input->post('nt_driver')) == 0) {
                $this->nt_drivers_tbl_model->insert();
                $_POST['nt_driver'] = $this->nt_drivers_tbl_model->get_max();
            } else {
                $_POST['nt_driver'] = $this->nt_drivers_tbl_model->get_data($this->input->post('nt_driver'));
            }

            if ($this->nt_carplates_tbl_model->check($this->input->post('nt_cars_plate')) == 0) {
                $this->nt_carplates_tbl_model->insert();
                $_POST['nt_cars_plate'] = $this->nt_carplates_tbl_model->get_max();
            } else {
                $_POST['nt_cars_plate'] = $this->nt_carplates_tbl_model->get_data($this->input->post('nt_cars_plate'));
            }

            if ($this->nt_car_grants_tbl_model->check($this->input->post('nt_cargrants')) == 0) {
                $this->nt_car_grants_tbl_model->insert();
                $_POST['nt_cargrants'] = $this->nt_car_grants_tbl_model->get_max();
            } else {
                $_POST['nt_cargrants'] = $this->nt_car_grants_tbl_model->get_data($this->input->post('nt_cargrants'));
            }



            $this->nt_reports_tbl_model->insert();
            $this->nt_assignments_tbl_model->insert($this->nt_reports_tbl_model->fetch_max_id());
            $this->nt_cars_control_tbl_model->insert($this->nt_reports_tbl_model->fetch_max_id());
            $this->nt_drivers_control_tbl_model->insert($this->nt_reports_tbl_model->fetch_max_id());
            $this->nt_cars_tbl_model->insert($this->nt_cars_control_tbl_model->fetch_max_id());
            $this->nt_drivers_data_tbl_model->insert($this->nt_drivers_control_tbl_model->fetch_max_id());
        }
        $this->load->model('nt_locations_model');
        $this->load->model('nt_carplates_tbl_model');
        $this->load->model('nt_car_grants_tbl_model');
        $this->load->model('nt_drivers_tbl_model');
        $this->load->model('nt_assignments_tbl_model');
        $this->view_data['nt_locations_dd'] = $this->nt_locations_model->fetch_all();
        $this->view_data['nt_carplates_dd'] = $this->nt_carplates_tbl_model->fetch_all();
        $this->view_data['nt_cargrants_dd'] = $this->nt_car_grants_tbl_model->fetch_all();
        $this->view_data['nt_drivers_dd'] = $this->nt_drivers_tbl_model->fetch_all();
        /*
          $this->load->model('nt_drivers_model');
          $this->load->model('nt_cars_model');
          $this->load->model('core_model');
          $this->view_data['nt_drivers_dd'] = $this->nt_drivers_model->fetch_all();
          $this->view_data['nt_cars_dd'] = $this->nt_cars_model->fetch_all();
          $this->view_data['nt_reference'] = $this->core_model->nt_reference()+1;
          $this->nt_drivers_model->insert();
          $this->nt_cars_model->insert();
          $this->core_model->update_nt_reference();
          //let's do some checking
          if($this->user){
          if($_POST){
          $this->load->model('nt_cars_control_model');
          $this->load->model('nt_drivers_control_model');
          $this->nt_cars_control_model->insert();
          $this->nt_drivers_control_model->insert();
          }
          $this->content_view = 'norgestaxi/_create';
          }else{
          //do some redirect
          }
         */

        $this->content_view = 'norgestaxi/_create';
    }

    function edit($type = null, $id = null) {
        if (!isset($type) && !isset($id)) {
            redirect(base_url('norgestaxi'), 'refresh');
        }

        if ($type == 'report') {
            $this->load->model('nt_reports_tbl_model');
            $this->load->model('nt_locations_model');
            $this->load->model('nt_assignments_tbl_model');
            //$this->nt_assignments_tbl_model->update($id);

            if ($_POST) {
                $this->nt_reports_tbl_model->update($id);
                unset($_POST);
            }
            $data['dd_location'] = $this->nt_locations_model->fetch_all();
            $data['data'] = $this->nt_reports_tbl_model->fetch_for_edit($id);


            echo $this->load->view('blackline/norgestaxi/edit_report', $data, true);
            exit;
        } else if ($type == 'driver') {
            $this->load->model('nt_drivers_data_tbl_model');
            $this->load->model('nt_drivers_tbl_model');
            $this->load->model('nt_drivers_data_tbl_model');
            $this->load->model('nt_drivers_control_tbl_model');
            if ($_POST) {
                if ($this->nt_drivers_tbl_model->check($this->input->post('nt_driver')) == 0) {
                    $this->nt_drivers_tbl_model->insert();
                    $_POST['nt_driver'] = $this->nt_drivers_tbl_model->get_max();
                } else {
                    $_POST['nt_driver'] = $this->nt_drivers_tbl_model->get_data($this->input->post('nt_driver'));
                }
                $this->nt_drivers_data_tbl_model->update();
                $this->nt_drivers_control_tbl_model->update();
                unset($_POST);
            }
            $data['nt_drivers_dd'] = $this->nt_drivers_tbl_model->fetch_all();
            $data['data'] = $this->nt_drivers_data_tbl_model->fetch_for_edit($id);
            //$this->content_view = 'norgestaxi/edit_driver';
            echo $this->load->view('blackline/norgestaxi/edit_driver', $data, true);
            exit;
        } else if ($type == 'car') {
            $this->load->model('nt_carplates_tbl_model');
            $this->load->model('nt_car_grants_tbl_model');
            $this->load->model('nt_cars_control_tbl_model');
            $this->load->model('nt_cars_tbl_model');
            if ($_POST) {
                if ($this->nt_carplates_tbl_model->check($this->input->post('nt_cars_plate')) <= 0) {
                    echo 'test';
                    $this->nt_carplates_tbl_model->insert();
                    $_POST['nt_cars_plate'] = $this->nt_carplates_tbl_model->get_max();
                } else {
                    $_POST['nt_cars_plate'] = $this->nt_carplates_tbl_model->get_data($this->input->post('nt_cars_plate'));
                }

                if ($this->nt_car_grants_tbl_model->check($this->input->post('nt_cargrants')) == 0) {
                    $this->nt_car_grants_tbl_model->insert();
                    $_POST['nt_cargrants'] = $this->nt_car_grants_tbl_model->get_max();
                } else {
                    $_POST['nt_cargrants'] = $this->nt_car_grants_tbl_model->get_data($this->input->post('nt_cargrants'));
                }
                $this->nt_cars_control_tbl_model->update();
                $this->nt_cars_tbl_model->update();
                unset($_POST);
            }

            $data['data'] = $this->nt_cars_control_tbl_model->fetch_for_edit($id);
            $data['nt_carplates'] = $this->nt_carplates_tbl_model->fetch_all();
            $data['nt_cargrants'] = $this->nt_car_grants_tbl_model->fetch_all();
            echo $this->load->view('blackline/norgestaxi/edit_car', $data, true);
            exit;
        } else {
            redirect(base_url('norgestaxi'), 'refresh');
        }
    }

    function view_report($id) {
        $this->load->model('nt_reports_tbl_model');
        $data['report'] = $this->nt_reports_tbl_model->fetch_for_view($id);
        echo $this->load->view('blackline/norgestaxi/view_report', $data, true);
        exit;
    }

}
