<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Core_model extends CI_Model{
	
		function fetch_all(){
			$query = $this->db->get('core');
			return $query->result();
		}
		
		function nt_reference(){
			$this->db->select_max('nt_reference');
			$query = $this->db->get('core');
			return $query->row()->nt_reference;
		}
		
		function update_nt_reference(){
			$data = array(
               'nt_reference' => $this->input->post('nt_reference')
            );
			$this->db->where('id', 1);
			$this->db->update('core', $data); 
		}
	}