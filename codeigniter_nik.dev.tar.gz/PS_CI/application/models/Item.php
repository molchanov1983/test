<?php

class Item extends ActiveRecord\Model {
  
}
