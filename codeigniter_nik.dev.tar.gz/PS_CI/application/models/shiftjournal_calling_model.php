<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shiftjournal_calling_model extends CI_Model {
	
	function fetch_all(){
		$query = $this->db->get('shiftjournal_calling');
		return $query->result();
	}

}