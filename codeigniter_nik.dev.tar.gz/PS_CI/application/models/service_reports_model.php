<?php	
if ( ! defined('BASEPATH')) exit('No direct script access allowed');	

class Service_reports_model extends CI_Model{				
		
	
	function get_reports_by_company_object($array){			
			$this->db->select('*');
			$this->db->from('service_reports');
			if($array!=null){
				$counter = 0;
				foreach($array as $a){
					if($counter==0)
						$this->db->where('object =', $a);
					else
						$this->db->or_where('object =', $a); 
					$counter++;
				}
			}
			$this->db->order_by("datetime", "desc"); 
			$query = $this->db->get();
			return $query->result();
	}

	function get_reports_by_company_name($data){
		$query = $this->db->get_where('service_reports',array('company_name'=>$data));
		return $query->result();
	}
	
	function get_new_service_reports_count(){
		$query = $this->db->get_where('service_reports',array('status'=>'new'));
		return $query->num_rows();
	}
}