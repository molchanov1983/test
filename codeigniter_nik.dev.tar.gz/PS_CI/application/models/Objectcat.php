<?php

class Objectcat extends Activerecord\Model{
	
	static $table_name = "objectcat";
	
}