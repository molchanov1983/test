<?php

class Shiftjournal extends ActiveRecord\Model
{
	 static $table_name = 'shiftjournal';
    
	/*
     static $belongs_to = array(
		 array('object')
	  );
	  */
}