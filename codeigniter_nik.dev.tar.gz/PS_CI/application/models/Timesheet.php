<?php

class Timesheet extends ActiveRecord\Model{
	
	static $table_name = "timesheets";	
	
	
}