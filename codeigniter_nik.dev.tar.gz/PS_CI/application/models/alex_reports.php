<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Alex_reports extends CI_Model {

    public static $_tableName = 'alex_main_report';
    public static $_tableNameOther = 'alex_main_report_other';
    public static $_tableDriverName = 'alex_driver';
    public static $_tableTaxiName = 'alex_taxi';
    public static $_tableCarName = 'alex_car';
    public static $_tableLocationName = 'alex_location';
    public static $_tableStatusName = 'alex_status';
    public static $_tableMain_StatusId = 'alex_main_report_status_id';
    public static $_tableAdditionparams = 'alex_addition_params';
    /**
     *
     * @param type $limit - integer
     * @param type $offset - integer
     * @param type $status_id - integer
     * @param $extra - array where i have addition filters
     * @return type - array
     */
    public function gerReports ( $limit, $offset, $status_id, $extra = array()) {
//add unique prefix for using it in helper to know what it is
        $add = empty($extra['awaiting_after_control'])  ? '' : 'CONCAT("date2_",ap.date)';

        $this->db->select(array(
                                'mr.id',
                                'CONCAT("mytime_",mr.date_time)',
               $add,
                                'CONCAT("taxiiddd_",t.taxi_name)',
                                'CONCAT("driveriddd_",d.driver_name)',
                                'CONCAT("carnppp_",c.car_number_plate)',
                                'CONCAT("locattt_",l.location_name)',
                                'u.tjenestenr',
                                'st.status_name',
                                'CONCAT("iddd_", mr.id,"_",st.status_name) as forlink',

                        ));
        $this->db->from(self::$_tableName.' as mr');
        $this->db->join(self::$_tableLocationName.' as l', 'l.id = mr.location_id');
        $this->db->join(self::$_tableMain_StatusId.' as mr_s', 'mr_s.report_id = mr.id');
        $this->db->join(self::$_tableTaxiName.' as t', 't.id = mr.taxi_id');
        $this->db->join(self::$_tableDriverName.' as d', 'd.id = mr.driver_id');
        $this->db->join(self::$_tableCarName.' as c', 'c.id = mr.car_id');
        $this->db->join(self::$_tableStatusName.' as st', 'st.id = mr_s.status_id');
        $this->db->join('users as u', 'u.id = mr.user_id');

        if ( ! empty($extra['awaiting_after_control']) ) {
            $this->db->join(self::$_tableAdditionparams.' as ap', 'ap.report_id = mr.id');
        }

        $this->db->where("`mr_s`.`status_id`", $status_id);
        if ( ! empty($extra['sinceDate']) ) {
             $this->db->where("`mr`.`date_time` >=", $extra['sinceDate']);
        }
        if ( ! empty($extra['untilDate']) ) {
            $this->db->where("`mr`.`date_time` <=", $extra['untilDate']);
        }

        $this->db->order_by('mr.id', 'DESC');

        $this->db->limit($limit, $offset);

        $query = $this->db->get();
        return  $query->result_array();
    }
    /**
     *  get count rows into db
     * @param $extra - addition rules
     * @return type - integer
     */
    public function getNumRowsInTheTable ($extra=array()) {
        // $extra['sinceDate']
        //select count(*) as count, status_id from alex_main_report GROUP BY status_id
        $this->db->select(array('count(*) as count','status_id','status_name'));
        $this->db->from(self::$_tableName.' as mr');
        $this->db->join(self::$_tableMain_StatusId.' as mr_s', 'mr_s.report_id = mr.id');
        $this->db->join(self::$_tableStatusName.' as sn', 'sn.id = mr_s.status_id');
        if ( ! empty($extra['sinceDate']) ) {
             $this->db->where("`date_time` >=", $extra['sinceDate']);
        }
        if ( ! empty($extra['untilDate']) ) {
            $this->db->where("`date_time` <=", $extra['untilDate']);
        }

        $this->db->group_by('status_id', 'ASC');

        if ( ! empty($extra['having']) ) {
            $this->db->having('status_id', $extra['having']['status_id']);
        }

        $query = $this->db->get();

//log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: sql this->db->last_query() - ".print_r($this->db->last_query(), true));
        return  $query->result_array();
    }
    /**
     *  get all fields from licalion table
     * @return type array
     */
    public function getAllLocation () {
        $query = $this->db->query('SELECT id,location_name FROM '.self::$_tableLocationName);
        return $query->result_array();
    }
    /**
     *  get all stust
     * @return type array
     */
    public function getAllStatus () {
        $query = $this->db->query('SELECT id,status_name FROM '.self::$_tableStatusName);
        return $query->result_array();
    }
/**
 * insert or update rows in the tables
 * @param type $tableName - string
 * @param type $data - array
 * @param type $extra array
 * @return type bool
 */
    public function saveDataToDifferentTables ($tableName, $data , $extra) {
        //here i used for where part of query and also parameter to make sure if ned to return inserted id
        $isNeedToReturnInsId = false;
        if ( isset($extra['returnInsId'] ) ) {
            $isNeedToReturnInsId = $extra['returnInsId'] ;
            unset($extra['returnInsId']);
        }


         if ( ! empty($extra) ) {  //update
            $keyArr = array_keys($extra);
            $this->db->where($keyArr[0], $extra[$keyArr[0]]);
            return $this->db->update($tableName, $data);
        } else {  //insert
            $insertedId =  $this->db->insert($tableName, $data);
            if ( $isNeedToReturnInsId ) {
                return $this->db->insert_id();
            }
            return $insertedId;

        }
    }


    /**
     * delete report from the table
     * @param $id - integer
     * @return - bool
     */
    public function deleteReportById ($id) {
            $where = array('id'=>$id);
            return $this->db->delete(self::$_tableName, $where);
    }

    /**
     * get all info of one report using its id
     * @param type $id - integer
     * @return array or false
     */
    public function getReportDataByReportId ($id) {

        $this->db->select(array(
                                'd.driver_name',
                                't.taxi_name',
                                'c.car_number_plate',
                                'mr.location_id',
                                'mr.date_time',
                                'l.location_name',
                                'u.tjenestenr',
                                's.status_name',
                                'o.taklampe',
                                'o.ikke_skadet_mkkete_bil',
                                'o.logo_fordr_og_tlf_nr_bakdr_frerside',
                                'o.logo_fordr_og_tlf_nr_bakdr_passasjerside',
                                'o.logo_og_tlf_pa_bilens_bakside',
                                'o.airportklistremerke',
                                'o.taksoblat',
                                'o.tilfredsstillende_uniform',
                                'o.gyldig_id_kort',
                                'o.id_kort_synlig',
                                'o.korrekt_kopi_siste_tur',
                                'o.content_one',
                                'o.content_two',

                        ));
        $this->db->from(self::$_tableName.' as mr');
        $this->db->join(self::$_tableDriverName.' as d', 'd.id = mr.driver_id');
        $this->db->join(self::$_tableCarName.' as c', 'c.id = mr.car_id');
        $this->db->join(self::$_tableTaxiName.' as t', 't.id = mr.taxi_id');
        $this->db->join(self::$_tableLocationName.' as l', 'l.id = mr.location_id');
        $this->db->join(self::$_tableMain_StatusId.' as st', 'st.report_id = mr.id');
        $this->db->join(self::$_tableStatusName.' as s', 's.id = st.status_id');
        $this->db->join(self::$_tableNameOther.' as o', 'o.report_id = mr.id');
        $this->db->join('users as u', 'u.id = mr.user_id');
        $this->db->where("`mr`.`id`", $id);
        $query = $this->db->get();

        return  $query->row();

    }
    /**
     *  get all data from different table. It needs for autocomplete where i will use returned from this function names
     * @param type $tableName- string
     * @param type $fieldName - string
     * @param $extra - extra parameters
     * @return array
     */
    public function getAllDataFromDifferentTable ($tableName, $fieldName, $extra = null) {
        $this->db->select(array(
                            $fieldName .' as field'
                        ));
        $this->db->from($tableName);
        if ( is_array($extra) ) {
            $keyArr = array_keys($extra);
            $this->db->where($keyArr[0], $extra[$keyArr[0]]);
        }
        $query = $this->db->get();
        $result = $query->result_array();

        return  $result;
    }
    /**
     * convert array to string
     * @param type $arrWithArr
     * @return string
     */
    public function convertArrToString ($arrWithArr) {
        $return = array();
        if ( empty($arrWithArr) ) {
            return '';
        }

        foreach ($arrWithArr as $key => $arr) {
            $return[] = $arr['field'];
        }
        return implode ( ',' ,  $return );
    }
/**
 *  insert driver if not exist and get driver id if exist
 * @param type $driverName - string
  * @return type - integer
 */
    public function setIfNotExistDriverNameAndGetDriverId( $driverName ) {
        $data = array(
            'driver_name' => $driverName
        );
        $insert_query = $this->db->insert_string(self::$_tableDriverName, $data);
        $insert_query = str_replace('INSERT INTO','INSERT IGNORE INTO',$insert_query);

        $this->db->query($insert_query);

        $isInserted = $this->db->affected_rows();
        if ($isInserted) {
           //get inserted id
            $insertedId = $this->db->insert_id();
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: driver inserted id - ".print_r($insertedId, true));
            return $insertedId;
        }
        //i am here if driver alrady exist
        $driverArr = $this->getAllDataFromDifferentTable(self::$_tableDriverName,'id',$data);
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: driver info - ".print_r($driverArr, true));
        return $driverArr[0]['field'];

    }
    /**
     *  insert taxi if it is not exist and get if it exist
     * @param type $TaxiName - string
     * @return type int
     */
    public function setIfNotExistTaxiNameAndGetTaxiId( $TaxiName ) {
        $data = array(
            'taxi_name' => $TaxiName
        );
        $insert_query = $this->db->insert_string(self::$_tableTaxiName, $data);
        $insert_query = str_replace('INSERT INTO','INSERT IGNORE INTO',$insert_query);

        $this->db->query($insert_query);

        $isInserted = $this->db->affected_rows();
        if ($isInserted) {
           //get inserted id
            $insertedId = $this->db->insert_id();
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: taxi inserted id - ".print_r($insertedId, true));
            return $insertedId;
        }
        //i am here if taxi alrady exist
        $taxiArr = $this->getAllDataFromDifferentTable(self::$_tableTaxiName,'id',$data);
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: taxi info - ".print_r($taxiArr, true));

        return $taxiArr[0]['field'];
    }
    /**
     *  insert car if it is not exist and get id if it isi exist
     * @param type $carNumberPlate - string
     * @return type - int
     */
     public function setIfNotExistCarnumberplateAndGetCarId( $carNumberPlate) {
        $data = array(
            'car_number_plate' => $carNumberPlate
        );
        $insert_query = $this->db->insert_string(self::$_tableCarName, $data);
        $insert_query = str_replace('INSERT INTO','INSERT IGNORE INTO',$insert_query);

        $this->db->query($insert_query);

        $isInserted = $this->db->affected_rows();
        if ($isInserted) {
           //get inserted id
            $insertedId = $this->db->insert_id();
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: car inserted id - ".print_r($insertedId, true));
            return $insertedId;
        }
        //i am here if taxi alrady exist
        $carArr = $this->getAllDataFromDifferentTable(self::$_tableCarName,'id',$data);
log_message('debug','       !!!  '.__METHOD__."::".__LINE__.":: car info - ".print_r($carArr, true));
        return $carArr[0]['field'];
    }

    public function startTransaction () {
        $this->db->trans_begin();
    }
    public function endTransaction () {
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            return false;
        }
        else
        {
            $this->db->trans_commit();
            return true;
        }
    }

}
