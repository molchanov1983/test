<?php

class Message extends ActiveRecord\Model {
  
}
