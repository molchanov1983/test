<?php

class Shift extends ActiveRecord\Model{
	
	static $table_name = "shiftjournal";	
	
	
}