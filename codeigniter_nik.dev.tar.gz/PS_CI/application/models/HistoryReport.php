<?php

class HistoryReport extends Activerecord\Model{
	
	static $table_name = "service_reports_history";
	
}