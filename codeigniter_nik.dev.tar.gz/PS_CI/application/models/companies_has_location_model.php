<?php	
if ( ! defined('BASEPATH')) exit('No direct script access allowed');	
class Companies_has_location_model extends CI_Model{	
			
	function insert($name,$company,$object){			
		$data = array(			   
		'location_name' => $name ,			   
		'company' => $company ,			   
		'object' => $object			
		);
		$this->db->insert('companies_has_location', $data); 		
	}

	function fetch_by_object($obj){
		$query = $this->db->get_where('companies_has_location',array('object'=>$obj));
		return $query->result();
	}
}