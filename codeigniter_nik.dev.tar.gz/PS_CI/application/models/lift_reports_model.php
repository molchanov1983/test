<?php	
if ( ! defined('BASEPATH')) exit('No direct script access allowed');	

class Lift_reports_model extends CI_Model{				
		
	
	function get_reports_by_company_object($array){			
			$this->db->select('*');
			$this->db->from('lift_reports');
			if($array!=null){
				$counter = 0;
				foreach($array as $a){
					if($counter==0)
						$this->db->where('object_name =', $a);
					else
						$this->db->or_where('object_name =', $a); 
					$counter++;
				}
			}
			$query = $this->db->get();
			return $query->result();
	}			
}