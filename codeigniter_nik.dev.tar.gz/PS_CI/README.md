codeigniter_nik
===============
for adding new module i did:
1 - add module-data to module table 
    id      name               link          type       icon        sort
    39   Norges Taxi v2      norgestaxi_v2    main     icon-list-alt  10
    38   Norges Taxi v2      norgestaxi_v2    client   icon-list-alt  10

2 - add module_id to table users->access
    table user:
    id   username ...    access
    10     nik          1,2,...39




//codeigniter procedure bug
http://stackoverflow.com/questions/4827752/calling-a-stored-procedure-from-codeigniters-active-record-class
(thats why i deleted created procedure)