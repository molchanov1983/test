(function() {

    var Norgestaxi_v2 = {
//it is on the main page
////////////////////////
        myOwnSelectLists: 'select.alex_select',
        oneTableDivClass : '.one_table',
        paginationClass : '.one_table_pagination',
        reportsTablDiv : '#reports_table',
        oneTablePaginationClass:'.one_table_pagination',
        //buttons delete, edit,print on the main page
        deleteReportButtons : 'a[data-target="#deleteReportModal"]',
        editReportButtons : 'a[data-target="#editReportModal"]',
        printReportButtons : '.printreportForJq',
        reportsDaterange : '#reports_daterange',
        containerFluidClass : '.container-fluid',
        reportsTableMessageId : '#reports_table_message',
        
//it is in modal windows
///////////////////////
        modalWindowAWithNameConfirnYes : 'confirn_yes',
        deleteReportModalId : '#deleteReportModal',
        editReportModalId : '#editReportModal',
        //checkboxes
        taklampeId : '#taklampe',
        ikke_skadet_mkkete_bilId : '#ikke_skadet_mkkete_bil',
        logo_fordr_og_tlf_nr_bakdr_frersideId : '#logo_fordr_og_tlf_nr_bakdr_frerside',
        logo_fordr_og_tlf_nr_bakdr_passasjersideId : '#logo_fordr_og_tlf_nr_bakdr_passasjerside',
        logo_og_tlf_pa_bilens_baksideId : '#logo_og_tlf_pa_bilens_bakside',
        airportklistremerkeId : '#airportklistremerke',
        taksoblatId : '#taksoblat',
        tilfredsstillende_uniformId : '#tilfredsstillende_uniform',
        gyldig_id_kortId : '#gyldig_id_kort',
        id_kort_synligId : '#id_kort_synlig',
        korrekt_kopi_siste_turId : '#korrekt_kopi_siste_tur',
 
        
        initialize: function() {
            this.extend();  
            this.modules();
            this.setUpListeners();
            this.initializeOtherPlugins();
            
        },
        extend: function() {
             $.extend(this, moduleNorgestaxi_v2);
        },
        modules: function() {

        },
        initializeOtherPlugins: function()
        {
            this.initializeDaterangepicker();
            $( "body" ) .on( "added_modals_html",true, $.proxy(this.initializeFormValidation, this) ); 
            $( "body" ) .on( "clear_message",true, $.proxy(this.clearMessageBox, this) ); 
             
        },
        setUpListeners: function() {
            var self = this;
            //when you change count reports per page
            $(this.reportsTablDiv).on('change', this.myOwnSelectLists, $.proxy(this.showNewCountRows, this))
            //before opening modal confirm window for deleting report we need to set report_id to the link
                                   .on('click',this.deleteReportButtons, $.proxy(this.onShowDeleteReportModalWindow, this))
                                   .on('click',this.editReportButtons, $.proxy(this.onShowEditReportModalWindow, this));
            
            //this is for loading modals html using ajax 
            //to make loading page faster
              //when i close edit report modal window  i need to clean all inputs value  (added_modals_html)
            $( "body" )
                    .on( "alex_document_ready", $.proxy(this.appendAllModalHtml, this))                 
                    .on( "added_modals_html", $.proxy(this.bindHiddenEventForEditModalWindow, this));
            // i did it below because when i try to find textarea the textarea were not found
                    //.on( "added_modals_html", function () {alert(1);self.initializeMarkdown()});
            
        },
        //clean all inputs when you close editing form
        bindHiddenEventForEditModalWindow : function () {
            var self = this;
            $(this.editReportModalId).on('hidden.bs.modal', function (e) {
               $(this).find('form')[0].reset();
               self.myGlobalvalidator.form.resetForm();
            })
        },
        //lazy loading all modal html
        appendAllModalHtml : function () {
            var postUrl = baseUrl + this.getModuleName()+'/ajaxGetAllModalHtml';
            var isAppend = this.helperAjaxAndAppendHtmlToBody(postUrl);
            if ( isAppend ) {
                //run autocomplete function
                this.getDataForAutocomplete();
            } else {
                console.error('error append modal windows');
            }
     
        },
        //when i click to some button i need to get its id and make right url for confirmation deleting
        onShowDeleteReportModalWindow : function (event){
            event.preventDefault();
            
            var $target = $(event.currentTarget);
            
            var nameAttr = $target.attr('name');
            var nameAttrArr = nameAttr.split(/_/);
            
            var confirmLink = $(this.deleteReportModalId).find('a[name='+this.modalWindowAWithNameConfirnYes+']');
            var currecnHrefAttr =confirmLink.data('url');
            confirmLink.attr('href', currecnHrefAttr+'/'+nameAttrArr[1]);          

        },
        //before showing edit form i need to get add report data from the server
        onShowEditReportModalWindow : function (event) {
            event.preventDefault();

            var $target = $(event.currentTarget);
            //we need to save this tagle as a global because when you will click update on the modal window we still need to know what table row you should update
            this.wasClicked = $target;
            
            var nameAttr = $target.attr('name');
            var nameAttrArr = nameAttr.split(/_/);
            var reportId = nameAttrArr[1];

            //here i need to get all data from the server
            var getUrl = baseUrl + this.getModuleName()+'/ajaxGetReportDataById/'+reportId;
            var isFilledOutForm = this.helperGetReportDataById(getUrl, reportId);
            if ( ! isFilledOutForm ) {
                //here i have error
                //close modal window
                $(this.editReportModalId).modal('toggle');               
                //show error message
                console.error('error from server');
            }
                 
        },
        //this is if you change value how many reports per table to show
        showNewCountRows: function(event) {
            //delete message if exist
            $( "body" ).trigger( "clear_message" ); 
            //load mask
            $(this.containerFluidClass).mask("Loading...");
            
            var self = this;
            var $target = $(event.currentTarget);
            var selectName = $target.attr('name');
            var selectNameArr = selectName.split(/_/);
            //get status id from the name
            var statusId = selectNameArr[1];
            //new count to show
            var selectedValue = $target.find('option:selected').val();
            //cretae url for ajax
            var postUrl = baseUrl + this.getModuleName()+'/ajaxGetReportsByStatusId/' + statusId + '/' + selectedValue;
            

            $.ajax({
                dataType: 'html',
                url: postUrl,
                success: function(htmldata) {
                   var oneTableDiv = $target.parents(self.oneTableDivClass);
                    oneTableDiv.find('table').remove();
                    oneTableDiv.find(self.paginationClass).remove();
                    oneTableDiv.append(htmldata);
                    //delete mask
                    $(self.containerFluidClass).unmask();
                },
                error: function (xhr, ajaxOptions, thrownError) {
                     $(self.containerFluidClass).unmask();
                }
            });

            return false;
        },
        initializeDaterangepicker : function () {
            var self = this;

            $(this.reportsDaterange).daterangepicker({
                ranges: {
                    'Idag': [new Date(), new Date()],
                    'Igår': [moment().subtract('days', 1), moment().subtract('days', 1)],
                    'Siste 7 dager': [moment().subtract('days', 6), moment()],
                    'Siste 30 dager': [moment().subtract('days', 29), moment()],
                    'Denne måned': [moment().startOf('month'), moment().endOf('month')],
                    'Siste måned': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                },
                opens: 'left',
                format: 'DD/MM/YYYY',
                separator: ' - ',
//                startDate: moment().subtract('days', 29),
//                endDate: new Date(),
                startDate: moment().subtract('days', 29),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '12/31/2030',
                locale: {
                    applyLabel: 'Ok',
                    fromLabel: 'Fra',
                    toLabel: 'Til',
                    customRangeLabel: 'Egendefinert',
                    daysOfWeek: ['Sø', 'Ma', 'Ti', 'On', 'To', 'Fr', 'Lø'],
                    monthNames: ['Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger'],
                dateLimit: false
            },
            function(start, end) {
                //check if start and end data is null
                if ( ! start || ! end )  {
                    return false;
                }
                //delete message if exist
                $( "body" ).trigger( "clear_message" ); 
            
                //load mask
                 $(self.containerFluidClass).mask("Loading...");
                 //need to hide message if we didnot have reports
                 $(self.reportsTableMessageId).hide();
                //change value in input 
               // $('#reports_daterange').val(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
                //here ajax for set new time filter value to the session
   
                var postUrl = baseUrl + self.getModuleName()+'/ajaxGetNewReportsByDateTime';
                var IsSaved = self.helperAjaxSetNewDateTimeFilter(postUrl, start.format('DD/MM/YYYY'), end.format('DD/MM/YYYY'));
                $(self.containerFluidClass).unmask();
                 //if error from the server                        
                if ( ! IsSaved ) {
                       //if we have error from server and didnot store new filter data
                    console.error('error from server');                  
                }   
            });
        },
        
        //////////////////////////////////////////////////////
        //////   HELPERS START  //////////////////////////////
        //////////////////////////////////////////////////////
        /**
         * get new reports using new filter date and time
         * @param {type} postUrl
         * @param {type} timeStartInt
         * @param {type} timeEndInt
         * @returns nothing ()
         */
        helperAjaxSetNewDateTimeFilter : function (postUrl, timeStart, timeEnd) {
    
            var self = this;
            var serurn = false;            
             $.ajax({
                dataType: 'html',
                url: postUrl,
                data : {since:timeStart,until: timeEnd},
                type: "POST",
                async:false,
                success: function(data) {
                    if ( data === '0' ) { // it means validation post parameters vas false
                        console.error('error from server');
                        console.log(data);
                    } else  if (data ==='' ) {
                        $(self.reportsTableMessageId).show();
                        $(self.reportsTablDiv).html(data);
                        serurn = true;
                    } else {
                        //i have html string from the server
                         // replace old html to new
                         $(self.reportsTablDiv).html(data);
                         serurn = true;
                    }
                }
            });
            return serurn;
        },
        helperAjaxGetReportsUsingNewDate : function ( url ) {

        },
        /**
         *  get html from the server and append it to body (it is html for mpal windows)
         * @param {type} postUrl string
         * 
         */
        helperAjaxAndAppendHtmlToBody : function (postUrl) {
            var self = this;
            var myreturn = false; 
            $.ajax({
                dataType: 'html',
                url: postUrl,
                async:false,
                success: function(htmldata) {
                    //append this html to body
                    $('body')
                            .append(htmldata)
                            .trigger( "added_modals_html" );    
                    //initialize markdown plugin
                    self.initializeMarkdown()
                    myreturn = true;
                }
               
            });
            return myreturn;
        },
        //creating ajax to the server to get report data
        helperGetReportDataById : function (postUrl, reportId) {
            var self = this;
            var myReturn = false;
            $.ajax({
                dataType: 'json',
                url: postUrl,
                async:false,
                success: function(data) { 
                   if (typeof data.error  !== 'undefined') {  //error form the server
                        console.error('error from server');
                        console.log(data);
                   } else if ( data.data.length && self.isJSON(data.data) ) {
                       //here i have valid json string from the server
                        myReturn =  self.fillOutTheForm(data.data, reportId);                       
                   }else if ( data.data.length && ! self.isJSON(data.data) ) {
                        console.error('error from server');
                        console.log(data);
                   } 
                }                
            });
            return myReturn;
        },
        //when i have report data from the server i need to fill out the form
        fillOutTheForm : function (jsonStr, reportId) {
            //make object from string
            var obj = $.parseJSON( jsonStr );

            var modal =  $(this.editReportModalId);

            modal.find( this.driverId ).val(obj.driver_name);
            modal.find( this.taxiId ).val(obj.taxi_name);
            modal.find( this.carPlateNumberId ).val(obj.car_number_plate);
            modal.find('select[name="kontroll_sted"] option[value='+obj.location_id+']').attr('selected','selected');
 
            //here i need to check checkboxes
            modal.find( this.taklampeId ).prop('checked', obj.taklampe*1);
//            modal.find( this.taklampeId ).prop('checked', '0');
            modal.find( this.ikke_skadet_mkkete_bilId ).prop('checked', obj.ikke_skadet_mkkete_bil*1);
            modal.find( this.logo_fordr_og_tlf_nr_bakdr_frersideId ).prop('checked', obj.logo_fordr_og_tlf_nr_bakdr_frerside*1);
            modal.find( this.logo_fordr_og_tlf_nr_bakdr_passasjersideId ).prop('checked', obj.logo_fordr_og_tlf_nr_bakdr_passasjerside*1);
            modal.find( this.logo_og_tlf_pa_bilens_baksideId ).prop('checked', obj.logo_og_tlf_pa_bilens_bakside*1);
            modal.find( this.airportklistremerkeId ).prop('checked', obj.airportklistremerke*1);
            modal.find( this.taksoblatId ).prop('checked', obj.taksoblat*1);
            modal.find( this.tilfredsstillende_uniformId ).prop('checked', obj.tilfredsstillende_uniform*1);
            modal.find( this.gyldig_id_kortId ).prop('checked', obj.gyldig_id_kort*1);
            modal.find( this.id_kort_synligId ).prop('checked', obj.id_kort_synlig*1);
            modal.find( this.korrekt_kopi_siste_turId ).prop('checked', obj.korrekt_kopi_siste_tur*1);
//textarea
            modal.find( this.textarea_one_id ).attr("value", obj.content_one);
            modal.find( this.textarea_two_id ).attr("value", obj.content_two);

            //i need to add report_id to form action
            var modalForm = $(this.form);
            var currentAction = modalForm.data('action'); 
      
            var newAction = currentAction+'Ajax/'+reportId;
            modalForm.attr('action', newAction);
       
          
            
            return true;
        },
        formHandler : function () {   
            var self = this;
            //this is button what was clicked and i found row what i need to update        
            var trShouldUpdate = this.wasClicked.parents('tr');

            var modalWindow = $(self.editReportModalId);
            //add mask
            modalWindow.mask("Loading...");
            //get input value
            var driverId = modalWindow.find(this.driverId).val();
            var taxiId = modalWindow.find(this.taxiId).val();
            var carNumberPlate = modalWindow.find(this.carPlateNumberId).val();
            var location = modalWindow.find(this.locationId+' option:selected').text();
   
            var $form = $(this.form);
            var action = $form.attr('action');
            $.post( action, $form.serialize(),function( data ) {
                //delete mask
                modalWindow.unmask();
                // i need to hide modal window
                $(self.editReportModalId).modal('hide');  
                //if we have no json from the server
                if ( ! self.isJSON(data) ) {
                    console.error('error from server');
                    console.log(data);
                    return false;
                }
                //make object from server json string
                var obj = $.parseJSON( data );
                //make html for message to insert into dom model
                var msgHtml = $("<div>");
                if (typeof obj.error  !== 'undefined') {  //error form the server
                        console.error('error from server');
                        console.log(data);
                        msgHtml.append('<div class="alert alert-error">'+obj.error+'</div>');
                }  else {
                        msgHtml.append('<div class="alert alert-success">'+obj.success+'</div>');
                }
        
                //replace html what i updated (into table)
                trShouldUpdate.find('span[name="taxiiddd"]').html(taxiId);
                trShouldUpdate.find('span[name="driveriddd"]').html(driverId);
                trShouldUpdate.find('span[name="carnppp"]').html(carNumberPlate);
                trShouldUpdate.find('span[name="locattt"]').html(location);

                //show successfull message to user              
                $(self.forJsMsg).html(msgHtml);
              
            });
            return false;
            
        },
        //delete error or successful messages from the page
        clearMessageBox : function () {
             $(this.forJsMsg).html('');
             $(this.alexAlertErrorDiv).remove();
             $(this.alexAlertSuccessDiv).remove();
        }
  
       

    }

    Norgestaxi_v2.initialize();

}());

      