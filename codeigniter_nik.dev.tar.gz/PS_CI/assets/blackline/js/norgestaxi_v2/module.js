(function() {

    window.moduleNorgestaxi_v2 = {
//settings  
        moduleName : 'norgestaxi_v2',
        forJsMsg : 'section[name="forJsMsg"]',
 //autocomplete inputs (this part of code for /norgestaxi_v2 and /norgestaxi_v2/create pages)
        driverId : '#driver_id',
        taxiId : '#taxi_id',
        carPlateNumberId : '#car_plate_number',
        locationId : '#kontroll_sted',
        form : '#form_create_report',  //for modal window and path = /create
        alexAlertErrorDiv : 'div[name="alex_alert_error"]',
        alexAlertSuccessDiv : 'div[name="alex_alert_success"]',
        
     
        form_taxi_id : '#taxi_id',
        form_car_plate_number : '#car_plate_number',
        
        //markdown editor
        textarea_one_id : '#textarea_one',
        textarea_two_id : '#textarea_two',
        
        
        
        myGlobalvalidator : {},
        
        initialize: function() {
            $( document ).ready( function () {
                  $('body').trigger( "alex_document_ready" ); 
             });
                         //Validation at least 1 capital letter, 6 digits limit. Example "A5412". 
            //They can type small letters, but it will be manipulated to capital letter automatically.
            $('body').on('keydown', this.form_taxi_id, $.proxy(this.makeUpperCase, this));
            $('body').on('keydown', this.form_car_plate_number, $.proxy(this.makeUpperCase, this));
            
        },
        makeUpperCase : function (event) {
            var self = (event.currentTarget);
            function myhandle() {
              self.value = self.value.toUpperCase()
            }
            setTimeout(myhandle, 0);
        },
        getModuleName : function () {
            return this.moduleName;
        },
        //(this part of code for /norgestaxi_v2 and /norgestaxi_v2/create pages)
        getDataForAutocomplete : function () {
  
            var self = this;
          //i need to make get reqest
            var getUrl = baseUrl + this.getModuleName()+'/ajaxDataForAutocomplere';
            $.get( getUrl, function( data ) { 

                //check if we have json string from server
                if ( self.isJSON( data ) ) {
                    //here i have valid data
                    var obj = $.parseJSON( data );
                    self.initializeAutocomplete(obj);                     
                } else {
                    // here i have not json string
                    console.error('error from server');
                }
               
            });
        },
        initializeAutocomplete : function (obj) {
            //here i have string like ""drever 1, driver 2 ..."" i need to delete first and last characters
            var driverStr = obj.drivers.substring(1, obj.drivers.length-1);
            var taxiStr = obj.taxi.substring(1, obj.taxi.length-1);
            var carNumberPlateStr = obj.carNumberPlate.substring(1, obj.carNumberPlate.length-1);
            //make array for autocomplete
            var driverArr = driverStr.split(",");
            var taxiArr = taxiStr.split(",");
            var carNumberPlateArr = carNumberPlateStr.split(",");

            //set rules
            $( this.driverId ).autocomplete({
                source: driverArr
            });
            $( this.taxiId ).autocomplete({
                source: taxiArr
            });
            $( this.carPlateNumberId ).autocomplete({
                source: carNumberPlateArr
            });
            
            
        },
        initializeMarkdown : function () {
            console.log($( this.textarea_one_id ));
            console.log($( this.textarea_one_id ).markdown());
            $( this.textarea_one_id ).markdown({
                  autofocus:false,
                   savable:false
            });
            $( this.textarea_two_id ).markdown({
                 autofocus:false,
                   savable:false
            });
//               $( this.textarea_one_id , this.textarea_two_id).markdown({
//                   autofocus:false,
//                   savable:false,
//                   isPreview:false
//               })
        },
        //////////////////////////////////////////////////////
        //////   HELPERS START  //////////////////////////////
        //////////////////////////////////////////////////////
              //check if i have json from the server
        isJSON : function (value) {
            try {
                JSON.stringify(value);
                return true;
            } catch (ex) {
                return false;
            }
        },
        //////////////////////////////////////////////////////
        //////   HELPERS END    //////////////////////////////
        //////////////////////////////////////////////////////
        initializeFormValidation : function (){

            var self = this;
            var isAjax = typeof arguments[0].data == 'undefined' ? false : true;
            
            var common = {};
            
            common.myRules = {
                    driver_id: {
                      required: true
                    },
                    taxi_id: {
                      required: true
                    },
                    car_plate_number: {
                      required: true
                    },
                    kontroll_sted: {
                      required: true
                    },
//                    taklampe: {
//                      required: true
//                    },
//                    ikke_skadet_mkkete_bil: {
//                      required: true
//                    },
//                    logo_fordr_og_tlf_nr_bakdr_frerside: {
//                      required: true
//                    },
//                    logo_fordr_og_tlf_nr_bakdr_passasjerside: {
//                        required: true
//                    },  
//                    logo_og_tlf_pa_bilens_bakside: {
//                        required: true
//                    },                    
//                    airportklistremerke: {
//                      required: true
//                    },
//                    taksoblat: {
//                        required: true
//                    },  
//                    tilfredsstillende_uniform: {
//                        required: true
//                    },
//                    gyldig_id_kort: {
//                      required: true
//                    },
//                    id_kort_synlig: {
//                        required: true
//                    },  
//                    korrekt_kopi_siste_tur: {
//                        required: true
//                    } 
                } ;
            
            this.myGlobalvalidator.form = $(this.form).validate({   
                rules : common.myRules,   
            });
            
            if ( isAjax ) {
                this.myGlobalvalidator.form.settings.submitHandler = $.proxy(this.formHandler, this);
            }
         
        }
        
    }

    moduleNorgestaxi_v2.initialize();

}());

      