$(function () {
        $('#barChart').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Chart Name'
            },
            subtitle: {
                text: 'Chart Name 2'
            },
            xAxis: {
                categories: [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sept',
                    'Oct',
                    'Nov',
                    'Dec'
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Label this'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                name: 'Annet',
                data: [49.9, 71.5, 106.4, 129.2, 144.0, 49.9, 71.5, 106.4, 129.2, 144.0, 129.2, 144.0]
    
            }, {
                name: 'Alarm',
                data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 71.5, 106.4, 129.2, 144.0, 129.2, 144.0]
    
            }, {
                name: 'Service',
                data: [48.9, 38.8, 39.3, 41.4, 47.0, 48.3, 83.6, 78.8, 98.5, 93.4, 106.0, 84.5]
    
            }, {
                name: 'Tjenestetlf',
                data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 93.4, 106.0, 84.5, 71.5, 106.4, 129.2]
    
            }, {
                name: 'Bortvisninger',
                data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 71.5, 106.4, 129.2, 144.0, 129.2, 144.0]
    
            }, {
                name: 'Anmeldelser',
                data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5,42.4, 33.2, 34.5, 39.7, 52.6, 75.5]
    
            }]
        });
   $('#pieChart').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: 'Browser market shares at a specific website, 2010'
            },
            tooltip: {
              pointFormat: '{series.name}: <b>{point.percentage}%</b>',
              percentageDecimals: 1
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function() {
                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Browser share',
                data: [
                    ['Firefox',   45.0],
                    ['IE',       26.8],
                    {
                        name: 'Chrome',
                        y: 12.8,
                        sliced: true,
                        selected: true
                    },
                    ['Safari',    8.5],
                    ['Opera',     6.2],
                    ['Others',   0.7]
                ]
            }]
        });
    });